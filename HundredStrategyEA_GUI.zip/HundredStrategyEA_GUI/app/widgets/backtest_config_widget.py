from PyQt6.QtWidgets import (
    QWidget, QFormLayout, QDateEdit, QComboBox, QDoubleSpinBox, QGroupBox, QHBoxLayout
)
from PyQt6.QtCore import QDate, Qt
from ..core.settings_model import BacktestConfig, TIMEFRAMES, TESTING_MODELS


class BacktestConfigWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._config = BacktestConfig()
        self._init_ui()

    def _init_ui(self):
        layout = QFormLayout(self)

        self._symbol = QComboBox()
        self._symbol.setEditable(True)
        for sym in ["EURUSD", "GBPUSD", "USDJPY", "AUDUSD", "USDCAD",
                     "GBPJPY", "EURJPY", "XAUUSD", "BTCUSD", "ETHUSD"]:
            self._symbol.addItem(sym)
        self._symbol.setCurrentText("EURUSD")
        layout.addRow("Symbol:", self._symbol)

        self._timeframe = QComboBox()
        self._timeframe.addItems(TIMEFRAMES)
        self._timeframe.setCurrentText("H1")
        layout.addRow("Timeframe:", self._timeframe)

        date_layout = QHBoxLayout()
        self._date_from = QDateEdit()
        self._date_from.setCalendarPopup(True)
        self._date_from.setDate(QDate(2024, 1, 1))
        self._date_to = QDateEdit()
        self._date_to.setCalendarPopup(True)
        self._date_to.setDate(QDate(2025, 12, 31))
        date_layout.addWidget(self._date_from)
        date_layout.addWidget(self._date_to)
        layout.addRow("Date Range:", date_layout)

        self._deposit = QDoubleSpinBox()
        self._deposit.setRange(100, 99999999)
        self._deposit.setValue(10000.0)
        self._deposit.setPrefix("$ ")
        layout.addRow("Deposit:", self._deposit)

        self._model = QComboBox()
        self._model.addItems(TESTING_MODELS)
        self._model.setCurrentText("Every tick")
        layout.addRow("Model:", self._model)

    def config(self) -> BacktestConfig:
        return BacktestConfig(
            symbol=self._symbol.currentText(),
            timeframe=self._timeframe.currentText(),
            date_from=self._date_from.date().toString("yyyy-MM-dd"),
            date_to=self._date_to.date().toString("yyyy-MM-dd"),
            deposit=self._deposit.value(),
            model=self._model.currentText(),
        )

    def set_config(self, cfg: BacktestConfig):
        self._symbol.setCurrentText(cfg.symbol)
        self._timeframe.setCurrentText(cfg.timeframe)
        parts = cfg.date_from.split("-")
        if len(parts) == 3:
            self._date_from.setDate(QDate(int(parts[0]), int(parts[1]), int(parts[2])))
        parts = cfg.date_to.split("-")
        if len(parts) == 3:
            self._date_to.setDate(QDate(int(parts[0]), int(parts[1]), int(parts[2])))
        self._deposit.setValue(cfg.deposit)
        idx = self._model.findText(cfg.model)
        if idx >= 0:
            self._model.setCurrentIndex(idx)
