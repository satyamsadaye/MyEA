import json
import os
from typing import List
from ..core.settings_model import EASettings, TerminalConfig, BacktestConfig


SETTINGS_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
                             "opencode_gui_settings.json")


def save_session(terminals: List[TerminalConfig], settings: EASettings,
                 backtest_cfg: BacktestConfig, active_count: int):
    data = {
        "terminals": [{"path": t.path, "data_folder": t.data_folder}
                      for t in terminals],
        "active_count": active_count,
        "settings": {k: v for k, v in settings.__dict__.items()
                     if not k.startswith("_")},
        "backtest": backtest_cfg.__dict__.copy(),
    }
    with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, default=str)


def load_session():
    if not os.path.isfile(SETTINGS_FILE):
        return None, None, None, 4
    with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
        data = json.load(f)
    terminals = []
    for t in data.get("terminals", []):
        terminals.append(TerminalConfig(
            path=t.get("path", ""),
            data_folder=t.get("data_folder", ""),
        ))
    settings = EASettings()
    for k, v in data.get("settings", {}).items():
        if hasattr(settings, k):
            setattr(settings, k, v)
    backtest_cfg = BacktestConfig()
    for k, v in data.get("backtest", {}).items():
        if hasattr(backtest_cfg, k):
            setattr(backtest_cfg, k, v)
    active_count = data.get("active_count", 4)
    return terminals, settings, backtest_cfg, active_count
