import os
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QTableWidget,
    QTableWidgetItem, QHeaderView, QFileDialog, QSpinBox, QLabel,
    QMessageBox, QAbstractItemView
)
from PyQt6.QtCore import Qt, pyqtSignal
from typing import List
from ..core.settings_model import TerminalConfig
from ..core.terminal_discovery import find_terminals_custom, auto_discover_terminals, _resolve_data_folder


STATUS_COLORS = {
    "Idle": Qt.GlobalColor.gray,
    "Ready": Qt.GlobalColor.darkGreen,
    "Running": Qt.GlobalColor.blue,
    "Complete": Qt.GlobalColor.darkGreen,
    "Error": Qt.GlobalColor.red,
}


class TerminalConfigWidget(QWidget):
    terminals_changed = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._terminals: List[TerminalConfig] = []
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        controls = QHBoxLayout()
        discover_btn = QPushButton("Auto-Discover")
        add_btn = QPushButton("Add Terminal")
        remove_btn = QPushButton("Remove Selected")
        self._count_spin = QSpinBox()
        self._count_spin.setRange(1, 20)
        self._count_spin.setValue(4)
        self._count_spin.setPrefix("Active: ")
        self._count_spin.valueChanged.connect(self._on_count_changed)

        discover_btn.clicked.connect(self._auto_discover)
        add_btn.clicked.connect(self._add_terminal)
        remove_btn.clicked.connect(self._remove_selected)

        controls.addWidget(discover_btn)
        controls.addWidget(add_btn)
        controls.addWidget(remove_btn)
        controls.addStretch()
        controls.addWidget(self._count_spin)
        layout.addLayout(controls)

        self._table = QTableWidget(0, 4)
        self._table.setHorizontalHeaderLabels(["Node #", "Terminal Path", "Data Folder", "Status"])
        self._table.horizontalHeader().setStretchLastSection(True)
        self._table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self._table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self._table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self._table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self._table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        layout.addWidget(self._table)

    def terminals(self) -> List[TerminalConfig]:
        active_count = self._count_spin.value()
        result = []
        for tc in self._terminals[:active_count]:
            tc.node_number = len(result) + 1
            result.append(tc)
        return result

    def all_terminals(self) -> List[TerminalConfig]:
        return list(self._terminals)

    def set_terminals(self, terminals: List[TerminalConfig]):
        self._terminals = list(terminals)
        self._count_spin.setValue(max(1, len(terminals)))
        self._refresh_table()

    def set_terminal_statuses(self, statuses: dict):
        for node, st in statuses.items():
            for row in range(self._table.rowCount()):
                item = self._table.item(row, 0)
                if item and item.text() == str(node):
                    st_item = self._table.item(row, 3)
                    if st_item:
                        st_item.setText(st.status)
                        color = STATUS_COLORS.get(st.status, Qt.GlobalColor.gray)
                        st_item.setForeground(color)
                    break

    def _refresh_table(self):
        self._table.setRowCount(0)
        active_count = self._count_spin.value()
        for i, tc in enumerate(self._terminals):
            row = self._table.rowCount()
            self._table.insertRow(row)
            node_num = i + 1
            self._table.setItem(row, 0, QTableWidgetItem(str(node_num)))
            self._table.setItem(row, 1, QTableWidgetItem(tc.path))
            self._table.setItem(row, 2, QTableWidgetItem(tc.data_folder))
            status = "Active" if i < active_count else "Disabled"
            st_item = QTableWidgetItem(status)
            st_item.setForeground(Qt.GlobalColor.darkGreen if i < active_count else Qt.GlobalColor.gray)
            self._table.setItem(row, 3, st_item)
        self.terminals_changed.emit()

    def _on_count_changed(self, val: int):
        self._refresh_table()

    def _auto_discover(self):
        found = auto_discover_terminals()
        if not found:
            found = find_terminals_custom([])
        if found:
            self._terminals = found
            self._count_spin.setValue(min(len(found), 10))
            self._refresh_table()
        else:
            QMessageBox.information(self, "Discovery",
                                    "No MT5 terminals found automatically.\n"
                                    "Click 'Add Terminal' to add paths manually.")

    def _add_terminal(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select Terminal Executable",
                                              "", "Executables (*.exe);;All Files (*)")
        if path:
            folder = os.path.dirname(path)
            data = _resolve_data_folder(path, folder)
            tc = TerminalConfig(path=path, data_folder=data, node_number=len(self._terminals) + 1)
            self._terminals.append(tc)
            self._refresh_table()

    def _remove_selected(self):
        rows = set()
        for item in self._table.selectedItems():
            rows.add(item.row())
        for row in sorted(rows, reverse=True):
            if row < len(self._terminals):
                self._terminals.pop(row)
        self._refresh_table()
