from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QTableWidget,
    QTableWidgetItem, QHeaderView, QProgressBar, QLabel, QTextEdit,
    QAbstractItemView, QGroupBox, QMessageBox
)
from PyQt6.QtCore import Qt, QTimer, pyqtSignal
from ..core.settings_model import TerminalStatus


class RunControlWidget(QWidget):
    run_requested = pyqtSignal()
    stop_requested = pyqtSignal()
    merge_requested = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        btn_layout = QHBoxLayout()
        self._run_btn = QPushButton("▶ RUN BACKTEST")
        self._run_btn.setMinimumHeight(40)
        self._run_btn.setStyleSheet("font-weight: bold; font-size: 14px;")
        self._stop_btn = QPushButton("■ STOP")
        self._stop_btn.setEnabled(False)
        self._merge_btn = QPushButton("⟳ MERGE RESULTS")
        self._merge_btn.setEnabled(False)

        self._run_btn.clicked.connect(self.run_requested)
        self._stop_btn.clicked.connect(self.stop_requested)
        self._merge_btn.clicked.connect(self.merge_requested)

        btn_layout.addWidget(self._run_btn)
        btn_layout.addWidget(self._stop_btn)
        btn_layout.addWidget(self._merge_btn)
        layout.addLayout(btn_layout)

        self._session_label = QLabel("Session: -")
        layout.addWidget(self._session_label)

        progress_group = QGroupBox("Backtest Progress")
        p_layout = QVBoxLayout(progress_group)

        self._overall_bar = QProgressBar()
        self._overall_bar.setRange(0, 100)
        self._overall_bar.setValue(0)
        self._overall_bar.setFormat("Overall: %p%")
        p_layout.addWidget(self._overall_bar)

        self._node_table = QTableWidget(0, 6)
        self._node_table.setHorizontalHeaderLabels([
            "Node", "Status", "Progress", "CPU %", "Memory", "Time"
        ])
        self._node_table.horizontalHeader().setStretchLastSection(True)
        self._node_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self._node_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        p_layout.addWidget(self._node_table)

        layout.addWidget(progress_group)

        self._log = QTextEdit()
        self._log.setReadOnly(True)
        self._log.setMaximumHeight(150)
        layout.addWidget(QLabel("Activity Log:"))
        layout.addWidget(self._log)

    def set_session_key(self, key: str):
        self._session_label.setText(f"Session: {key}")

    def log_message(self, msg: str):
        from datetime import datetime
        ts = datetime.now().strftime("%H:%M:%S")
        self._log.append(f"[{ts}] {msg}")

    def update_statuses(self, statuses: dict):
        for node, st in statuses.items():
            self._update_node_row(node, st)
        self._update_overall(statuses)

    def _update_node_row(self, node: int, st: TerminalStatus):
        for row in range(self._node_table.rowCount()):
            item = self._node_table.item(row, 0)
            if item and item.text() == str(node):
                self._node_table.setItem(row, 1, QTableWidgetItem(st.status))
                self._node_table.setItem(row, 2, QTableWidgetItem(f"{st.progress:.0f}%"))
                self._node_table.setItem(row, 3, QTableWidgetItem(f"{st.cpu_percent:.1f}%"))
                self._node_table.setItem(row, 4, QTableWidgetItem(f"{st.memory_mb:.0f} MB"))
                mins, secs = divmod(st.elapsed_seconds, 60)
                hours, mins = divmod(mins, 60)
                if hours > 0:
                    self._node_table.setItem(row, 5, QTableWidgetItem(f"{hours}h {mins}m"))
                else:
                    self._node_table.setItem(row, 5, QTableWidgetItem(f"{mins}m {secs}s"))
                return

        row = self._node_table.rowCount()
        self._node_table.insertRow(row)
        self._node_table.setItem(row, 0, QTableWidgetItem(str(node)))
        self._node_table.setItem(row, 1, QTableWidgetItem(st.status))
        self._node_table.setItem(row, 2, QTableWidgetItem(f"{st.progress:.0f}%"))
        self._node_table.setItem(row, 3, QTableWidgetItem(f"{st.cpu_percent:.1f}%"))
        self._node_table.setItem(row, 4, QTableWidgetItem(f"{st.memory_mb:.0f} MB"))
        self._node_table.setItem(row, 5, QTableWidgetItem("0s"))

    def _update_overall(self, statuses: dict):
        if not statuses:
            return
        total_progress = sum(st.progress for st in statuses.values())
        count = len(statuses)
        avg = total_progress / count if count > 0 else 0
        self._overall_bar.setValue(int(avg))

    def set_running_state(self, running: bool):
        self._run_btn.setEnabled(not running)
        self._stop_btn.setEnabled(running)
        self._merge_btn.setEnabled(not running)

    def enable_merge(self, enabled: bool):
        self._merge_btn.setEnabled(enabled)

    def reset(self):
        self._node_table.setRowCount(0)
        self._overall_bar.setValue(0)
        self._log.clear()
        self.set_running_state(False)
        self._merge_btn.setEnabled(False)
