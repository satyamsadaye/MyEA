"""
MT5 Terminal UI Automation via pywinauto.

Controls the MetaTrader 5 Strategy Tester to:
- Open the terminal
- Show the Strategy Tester panel
- Select EA, symbol, date range
- Click Start
- Monitor progress
- Detect completion

Fallback: if pywinauto not installed, uses win32gui SendKeys approach.
"""

import os
import time
import threading
import subprocess
from typing import Optional, Callable

HAVE_PYWINAUTO = False
HAVE_WIN32GUI = False

try:
    import pywinauto
    from pywinauto import Application, timings
    HAVE_PYWINAUTO = True
except ImportError:
    pywinauto = None

try:
    import win32gui
    import win32con
    import win32api
    import win32process
    HAVE_WIN32GUI = True
except ImportError:
    win32gui = None
    win32con = None
    win32api = None


TERMINAL_TITLE_PATTERNS = ["MetaTrader", "Meta Trader"]
TESTER_BUTTON_TEXTS = ["Start", "Test", "&Start", "&Test"]
EA_COMBO_LABEL = "Expert Advisor:"
SYMBOL_COMBO_LABEL = "Symbol:"


class MT5AutomationError(Exception):
    pass


def find_terminal_window(timeout: float = 60.0):
    """Wait for an MT5 terminal window to appear."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        def enum_callback(hwnd, windows):
            if win32gui.IsWindowVisible(hwnd):
                text = win32gui.GetWindowText(hwnd)
                for pattern in TERMINAL_TITLE_PATTERNS:
                    if pattern.lower() in text.lower():
                        windows.append((hwnd, text))
                        return
            return True
        windows = []
        if win32gui:
            win32gui.EnumWindows(enum_callback, windows)
            if windows:
                return windows[0][0]
        time.sleep(1.0)
    return None


def send_keystroke(hwnd, key: str, modifier: int = 0):
    """Send a keystroke to a window."""
    if not HAVE_WIN32GUI:
        return False
    try:
        win32api.SendMessage(hwnd, win32con.WM_KEYDOWN, ord(key), 0)
        win32api.SendMessage(hwnd, win32con.WM_KEYUP, ord(key), 0)
        return True
    except Exception:
        return False


def send_ctrl_r(hwnd) -> bool:
    """Send Ctrl+R to toggle Strategy Tester panel."""
    if not HAVE_WIN32GUI:
        return False
    try:
        win32api.SendMessage(hwnd, win32con.WM_KEYDOWN, ord('R'), 0)
        win32api.SendMessage(hwnd, win32con.WM_KEYUP, ord('R'), 0)
        return True
    except Exception:
        return False


def send_f5(hwnd) -> bool:
    """Send F5 to start/stop the Strategy Tester."""
    if not HAVE_WIN32GUI:
        return False
    try:
        VK_F5 = 0x74
        win32api.PostMessage(hwnd, win32con.WM_KEYDOWN, VK_F5, 0)
        win32api.PostMessage(hwnd, win32con.WM_KEYUP, VK_F5, 0)
        return True
    except Exception:
        return False


def is_tester_running(hwnd) -> bool:
    """
    Check if the tester is running by looking for status text.
    Tester status bar typically shows progress when running.
    """
    if not HAVE_WIN32GUI:
        return False
    text = win32gui.GetWindowText(hwnd)
    running_indicators = ["%", "testing", "optimization", "pass", "processing"]
    for ind in running_indicators:
        if ind.lower() in text.lower():
            return True
    return False


class PywinautoController:
    """Controls MT5 using pywinauto (more reliable)."""

    def __init__(self, exe_path: str, node_number: int):
        self.exe_path = exe_path
        self.node_number = node_number
        self.app: Optional[Application] = None
        self.main_window = None
        self._process: Optional[subprocess.Popen] = None
        self._pid: Optional[int] = None
        self._running = False
        self._progress = 0.0
        self._status = "Idle"
        self._error = ""

    @property
    def pid(self) -> Optional[int]:
        return self._pid

    @property
    def progress(self) -> float:
        return self._progress

    @property
    def status(self) -> str:
        return self._status

    @property
    def error(self) -> str:
        return self._error

    def launch_and_wait(self, timeout: float = 60.0) -> bool:
        """Launch the terminal and wait for it to be ready."""
        self._status = "Starting"
        try:
            self._process = subprocess.Popen(
                [self.exe_path],
                cwd=os.path.dirname(self.exe_path),
            )
            self._pid = self._process.pid
        except Exception as e:
            self._status = "Error"
            self._error = f"Launch failed: {e}"
            return False

        try:
            self.app = Application(backend="win32").connect(
                process=self._pid, timeout=int(timeout)
            )
            self.main_window = self.app.top_window()
            self.main_window.wait("visible", timeout=30)
            self._status = "Running"
            return True
        except Exception as e:
            self._status = "Error"
            self._error = f"Connect failed: {e}"
            return False

    def open_tester(self) -> bool:
        """Open the Strategy Tester panel (Ctrl+R)."""
        if not self.main_window:
            self._status = "Error"
            self._error = "No window"
            return False
        try:
            self.main_window.type_keys("^r")
            time.sleep(2.0)
            return True
        except Exception as e:
            self._status = "Error"
            self._error = f"Open tester failed: {e}"
            return False

    def select_ea(self, ea_name: str = "HundredStrategyEA") -> bool:
        """Select the EA from the dropdown."""
        try:
            combo = self.main_window.ComboBoxEx.wait("enabled", timeout=10)
            if combo:
                combo.select(ea_name)
                time.sleep(0.5)
                return True
            return False
        except Exception:
            try:
                dlg = self.main_window.child_window(title=EA_COMBO_LABEL, control_type="ComboBox")
                if dlg.exists():
                    dlg.select(ea_name)
                    time.sleep(0.5)
                    return True
            except Exception:
                pass
            return False

    def click_start(self) -> bool:
        """Click the Start button in the tester panel."""
        if not HAVE_PYWINAUTO:
            return False
        try:
            for attempt in range(5):
                for btn_text in TESTER_BUTTON_TEXTS:
                    try:
                        btn = self.main_window.child_window(title=btn_text, control_type="Button")
                        if btn.exists():
                            btn.click()
                            time.sleep(1.0)
                            self._status = "Running"
                            self._running = True
                            return True
                    except Exception:
                        continue
                time.sleep(1.0)
            self._status = "Error"
            self._error = "Start button not found"
            return False
        except Exception as e:
            self._status = "Error"
            self._error = f"Click start failed: {e}"
            return False

    def monitor_progress(self, on_status: Optional[Callable] = None) -> float:
        """Monitor tester progress by reading status bar text."""
        max_wait = 7200
        start = time.time()
        while self._running and (time.time() - start) < max_wait:
            try:
                text = self.main_window.window_text()
                import re
                pct_matches = re.findall(r'(\d+)%', text)
                if pct_matches:
                    self._progress = float(pct_matches[-1])
                if "finished" in text.lower() or "completed" in text.lower():
                    self._progress = 100.0
                    self._running = False
                    self._status = "Complete"
                    break
            except Exception:
                pass
            if on_status:
                on_status()
            time.sleep(2.0)

        if self._running and (time.time() - start) >= max_wait:
            self._status = "Error"
            self._error = "Timeout"
        return self._progress

    def stop(self):
        self._running = False
        try:
            if self._process:
                self._process.terminate()
                self._process.wait(timeout=5)
        except Exception:
            try:
                if self._process:
                    self._process.kill()
            except Exception:
                pass


class Win32Controller:
    """Fallback controller using win32gui SendKeys approach."""

    def __init__(self, exe_path: str, node_number: int):
        self.exe_path = exe_path
        self.node_number = node_number
        self._process: Optional[subprocess.Popen] = None
        self._hwnd: Optional[int] = None
        self._pid: Optional[int] = None
        self._running = False
        self._progress = 0.0
        self._status = "Idle"
        self._error = ""

    @property
    def pid(self) -> Optional[int]:
        return self._pid

    @property
    def progress(self) -> float:
        return self._progress

    @property
    def status(self) -> str:
        return self._status

    @property
    def error(self) -> str:
        return self._error

    def launch_and_wait(self, timeout: float = 60.0) -> bool:
        self._status = "Starting"
        try:
            self._process = subprocess.Popen(
                [self.exe_path],
                cwd=os.path.dirname(self.exe_path),
            )
            self._pid = self._process.pid
        except Exception as e:
            self._status = "Error"
            self._error = f"Launch failed: {e}"
            return False

        self._hwnd = find_terminal_window(timeout)
        if self._hwnd:
            self._status = "Running"
            return True
        self._status = "Error"
        self._error = "Window not found"
        return False

    def open_tester(self) -> bool:
        if not self._hwnd:
            return False
        self._status = "Configuring"
        send_ctrl_r(self._hwnd)
        time.sleep(3.0)
        return True

    def click_start(self) -> bool:
        if not self._hwnd:
            return False
        self._status = "Starting Test"
        send_f5(self._hwnd)
        time.sleep(2.0)
        self._running = True
        self._status = "Running"
        return True

    def monitor_progress(self, on_status: Optional[Callable] = None) -> float:
        max_wait = 7200
        start = time.time()
        while self._running and (time.time() - start) < max_wait:
            if self._hwnd:
                text = win32gui.GetWindowText(self._hwnd)
                import re
                pct_matches = re.findall(r'(\d+)%', text)
                if pct_matches:
                    self._progress = float(pct_matches[-1])
                if "finished" in text.lower() or "completed" in text.lower():
                    self._progress = 100.0
                    self._running = False
                    self._status = "Complete"
                    break
            if on_status:
                on_status()
            time.sleep(2.0)
        if self._running and (time.time() - start) >= max_wait:
            self._status = "Error"
            self._error = "Timeout"
        return self._progress

    def stop(self):
        self._running = False
        try:
            if self._process:
                self._process.terminate()
                self._process.wait(timeout=5)
        except Exception:
            try:
                if self._process:
                    self._process.kill()
            except Exception:
                pass


def create_controller(exe_path: str, node_number: int):
    """Create the best available controller."""
    if HAVE_PYWINAUTO:
        return PywinautoController(exe_path, node_number)
    if HAVE_WIN32GUI:
        return Win32Controller(exe_path, node_number)
    return None
