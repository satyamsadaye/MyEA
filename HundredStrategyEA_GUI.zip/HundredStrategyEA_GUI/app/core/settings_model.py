from dataclasses import dataclass, field
from typing import Optional, Dict

STRATEGY_MODE_OPTS = ["STRATEGY_ALL", "STRATEGY_SINGLE"]
SIGNAL_DIRECTION_OPTS = ["SIGNAL_BUY_ONLY", "SIGNAL_SELL_ONLY", "SIGNAL_BOTH"]
LOT_MODE_OPTS = ["LOT_RISK_CURRENT_BALANCE", "LOT_RISK_STARTING_BALANCE", "LOT_FIXED"]
STOP_MODE_OPTS = ["STOP_ATR_MULTIPLIER", "STOP_FIXED_POINTS", "STOP_FIXED_MONEY"]
PROP_STRATEGY_MODE_OPTS = ["PROP_STRATEGY_ALL", "PROP_STRATEGY_CUSTOM"]
PROP_SPAWN_INTERVAL_OPTS = [
    "SPAWN_DAILY_AT_RESUME", "SPAWN_EVERY_1H", "SPAWN_EVERY_2H", "SPAWN_EVERY_3H",
    "SPAWN_EVERY_4H", "SPAWN_EVERY_5H", "SPAWN_EVERY_6H", "SPAWN_EVERY_12H", "SPAWN_EVERY_20H",
    "SPAWN_EVERY_1M", "SPAWN_EVERY_3M", "SPAWN_EVERY_5M", "SPAWN_EVERY_15M", "SPAWN_EVERY_30M"
]

ENUM_VALUE_MAP: Dict[str, Dict[str, int]] = {
    "ENUM_STRATEGY_MODE": {"STRATEGY_ALL": 0, "STRATEGY_SINGLE": 1},
    "ENUM_SIGNAL_DIRECTION": {"SIGNAL_BUY_ONLY": 0, "SIGNAL_SELL_ONLY": 1, "SIGNAL_BOTH": 2},
    "ENUM_LOT_MODE": {"LOT_RISK_CURRENT_BALANCE": 0, "LOT_RISK_STARTING_BALANCE": 1, "LOT_FIXED": 2},
    "ENUM_STOP_MODE": {"STOP_ATR_MULTIPLIER": 0, "STOP_FIXED_POINTS": 1, "STOP_FIXED_MONEY": 2},
    "ENUM_PROP_STRATEGY_MODE": {"PROP_STRATEGY_ALL": 0, "PROP_STRATEGY_CUSTOM": 1},
    "ENUM_PROP_SPAWN_INTERVAL": {
        "SPAWN_DAILY_AT_RESUME": 0, "SPAWN_EVERY_1H": 1, "SPAWN_EVERY_2H": 2,
        "SPAWN_EVERY_3H": 3, "SPAWN_EVERY_4H": 4, "SPAWN_EVERY_5H": 5,
        "SPAWN_EVERY_6H": 6, "SPAWN_EVERY_12H": 12, "SPAWN_EVERY_20H": 20,
        "SPAWN_EVERY_1M": -1, "SPAWN_EVERY_3M": -3, "SPAWN_EVERY_5M": -5,
        "SPAWN_EVERY_15M": -15, "SPAWN_EVERY_30M": -30,
    },
}

ENUM_INT_TO_STRING: Dict[str, Dict[int, str]] = {}
for enum_name, mapping in ENUM_VALUE_MAP.items():
    ENUM_INT_TO_STRING[enum_name] = {v: k for k, v in mapping.items()}


@dataclass
class EASettings:
    strategy_mode: str = "STRATEGY_ALL"
    selected_strategy: int = 1
    allowed_direction: str = "SIGNAL_BOTH"
    min_votes_to_trade: int = 1
    one_trade_per_bar: bool = True
    reverse_signals: bool = False

    max_open_positions: int = 1
    magic_number: int = 100260629
    slippage_points: int = 30

    lot_mode: str = "LOT_RISK_CURRENT_BALANCE"
    risk_per_trade_percent: float = 1.0
    custom_starting_balance: float = 10000.0
    fixed_lot: float = 0.01
    max_lot: float = 10.0

    stop_loss_mode: str = "STOP_ATR_MULTIPLIER"
    take_profit_mode: str = "STOP_ATR_MULTIPLIER"
    atr_period: int = 14
    sl_atr_multiplier: float = 2.0
    tp_atr_multiplier: float = 3.0
    fixed_sl_points: float = 300.0
    fixed_tp_points: float = 600.0
    sl_money: float = 50.0
    tp_money: float = 100.0
    place_broker_sl_tp: bool = True

    enable_virtual_dollar_exit: bool = False
    virtual_exit_lot: float = 0.05
    virtual_take_profit_money: float = 50.0
    virtual_stop_loss_money: float = 25.0
    disable_broker_stops_when_virtual: bool = True

    enable_protection_stops: bool = True
    stop_profit_money: float = 0.0
    stop_loss_money: float = 0.0
    stop_drawdown_money: float = 0.0
    stop_profit_percent_of_start: float = 0.0
    stop_loss_percent_of_start: float = 0.0
    stop_drawdown_percent_of_start: float = 0.0
    close_positions_when_protection_hit: bool = True

    enable_margin_check: bool = True
    max_margin_percent_per_trade: float = 80.0

    enable_global_time_controls: bool = True
    global_pause_hour: int = 18
    global_pause_minute: int = 30
    global_close_hour: int = 19
    global_close_minute: int = 30
    global_resume_hour: int = 1
    global_resume_minute: int = 30

    enable_propfirm_backtest: bool = False
    prop_strategy_mode: str = "PROP_STRATEGY_ALL"
    prop_custom_strategies: str = ""
    prop_starting_balance: float = 5000.0
    prop_max_total_dd_percent: float = 6.0
    prop_profit_target_percent: float = 10.0
    prop_enable_daily_dd: bool = True
    prop_daily_dd_percent: float = 4.0
    prop_daily_buffer_percent: float = 1.0
    prop_daily_reset_hour: int = 0
    prop_daily_reset_minute: int = 0
    prop_pause_hour: int = 18
    prop_pause_minute: int = 30
    prop_close_hour: int = 19
    prop_close_minute: int = 30
    prop_resume_hour: int = 1
    prop_resume_minute: int = 30
    prop_rolling_start: bool = True
    prop_spawn_interval: str = "SPAWN_DAILY_AT_RESUME"
    prop_max_start_days: int = 0
    prop_html_report_name: str = "Propfirm_100_Strategy_Report.html"
    prop_recency_half_life_days: float = 14.0

    enable_csv_log: bool = True
    log_file_name: str = "HundredStrategyEA_Log.csv"
    print_detailed_log: bool = True

    enable_receiver_connection: bool = False
    receiver_copier_key: str = "client1"
    receiver_poll_interval_ms: int = 500

    @property
    def parallel_mode(self) -> int:
        return 0

    @property
    def parallel_node_number(self) -> int:
        return 1

    @property
    def parallel_total_nodes(self) -> int:
        return 1

    @property
    def parallel_session_key(self) -> str:
        return ""

    ENUM_FIELDS = {
        "strategy_mode": STRATEGY_MODE_OPTS,
        "allowed_direction": SIGNAL_DIRECTION_OPTS,
        "lot_mode": LOT_MODE_OPTS,
        "stop_loss_mode": STOP_MODE_OPTS,
        "take_profit_mode": STOP_MODE_OPTS,
        "prop_strategy_mode": PROP_STRATEGY_MODE_OPTS,
        "prop_spawn_interval": PROP_SPAWN_INTERVAL_OPTS,
    }

    BOOL_FIELDS = {
        "one_trade_per_bar", "reverse_signals", "place_broker_sl_tp",
        "enable_virtual_dollar_exit", "disable_broker_stops_when_virtual",
        "enable_protection_stops", "close_positions_when_protection_hit",
        "enable_margin_check", "enable_global_time_controls",
        "enable_propfirm_backtest", "prop_enable_daily_dd",
        "prop_rolling_start", "enable_csv_log", "print_detailed_log",
        "enable_receiver_connection",
    }


@dataclass
class TerminalConfig:
    path: str
    node_number: int = 1
    data_folder: str = ""
    enabled: bool = True


@dataclass
class BacktestConfig:
    symbol: str = "EURUSD"
    timeframe: str = "H1"
    date_from: str = "2024-01-01"
    date_to: str = "2025-12-31"
    deposit: float = 10000.0
    model: str = "Every tick"


@dataclass
class TerminalStatus:
    node_number: int
    path: str
    pid: Optional[int] = None
    cpu_percent: float = 0.0
    memory_mb: float = 0.0
    status: str = "Idle"
    progress: float = 0.0
    elapsed_seconds: int = 0
    error: str = ""


TIMEFRAMES = ["M1", "M5", "M15", "M30", "H1", "H4", "D1", "W1", "MN"]
TESTING_MODELS = ["Every tick", "Control points", "Open prices only", "Every tick based on real ticks"]

MODEL_INT_TO_STR = {0: "Every tick", 1: "Control points", 2: "Open prices only",
                    3: "Every tick based on real ticks", 4: "Every tick based on real ticks"}
