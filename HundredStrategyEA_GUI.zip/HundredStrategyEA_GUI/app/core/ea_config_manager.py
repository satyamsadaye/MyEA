import os
import codecs
from typing import Optional, Dict, Tuple
from .settings_model import (
    EASettings, BacktestConfig, ENUM_VALUE_MAP, ENUM_INT_TO_STRING,
    MODEL_INT_TO_STR, TIMEFRAMES
)

PROPX_INI_PATH = os.path.expanduser("~/Desktop/propx.ini")

SET_FIELD_MAP = {
    "StrategyMode": ("strategy_mode", "enum", "ENUM_STRATEGY_MODE"),
    "SelectedStrategy": ("selected_strategy", "int", None),
    "AllowedDirection": ("allowed_direction", "enum", "ENUM_SIGNAL_DIRECTION"),
    "MinVotesToTrade": ("min_votes_to_trade", "int", None),
    "OneTradePerBar": ("one_trade_per_bar", "bool", None),
    "ReverseSignals": ("reverse_signals", "bool", None),
    "MaxOpenPositions": ("max_open_positions", "int", None),
    "MagicNumber": ("magic_number", "int", None),
    "SlippagePoints": ("slippage_points", "int", None),
    "LotMode": ("lot_mode", "enum", "ENUM_LOT_MODE"),
    "RiskPerTradePercent": ("risk_per_trade_percent", "float", None),
    "CustomStartingBalance": ("custom_starting_balance", "float", None),
    "FixedLot": ("fixed_lot", "float", None),
    "MaxLot": ("max_lot", "float", None),
    "StopLossMode": ("stop_loss_mode", "enum", "ENUM_STOP_MODE"),
    "TakeProfitMode": ("take_profit_mode", "enum", "ENUM_STOP_MODE"),
    "AtrPeriod": ("atr_period", "int", None),
    "SlAtrMultiplier": ("sl_atr_multiplier", "float", None),
    "TpAtrMultiplier": ("tp_atr_multiplier", "float", None),
    "FixedSlPoints": ("fixed_sl_points", "float", None),
    "FixedTpPoints": ("fixed_tp_points", "float", None),
    "SlMoney": ("sl_money", "float", None),
    "TpMoney": ("tp_money", "float", None),
    "PlaceBrokerStopLossTakeProfit": ("place_broker_sl_tp", "bool", None),
    "EnableVirtualDollarExit": ("enable_virtual_dollar_exit", "bool", None),
    "VirtualExitLot": ("virtual_exit_lot", "float", None),
    "VirtualTakeProfitMoney": ("virtual_take_profit_money", "float", None),
    "VirtualStopLossMoney": ("virtual_stop_loss_money", "float", None),
    "DisableBrokerStopsWhenVirtualExitOn": ("disable_broker_stops_when_virtual", "bool", None),
    "EnableProtectionStops": ("enable_protection_stops", "bool", None),
    "StopProfitMoney": ("stop_profit_money", "float", None),
    "StopLossMoney": ("stop_loss_money", "float", None),
    "StopDrawdownMoney": ("stop_drawdown_money", "float", None),
    "StopProfitPercentOfStart": ("stop_profit_percent_of_start", "float", None),
    "StopLossPercentOfStart": ("stop_loss_percent_of_start", "float", None),
    "StopDrawdownPercentOfStart": ("stop_drawdown_percent_of_start", "float", None),
    "ClosePositionsWhenProtectionHit": ("close_positions_when_protection_hit", "bool", None),
    "EnableMarginCheck": ("enable_margin_check", "bool", None),
    "MaxMarginPercentPerTrade": ("max_margin_percent_per_trade", "float", None),
    "EnableGlobalTimeControls": ("enable_global_time_controls", "bool", None),
    "GlobalPauseSignalsHourUTC": ("global_pause_hour", "int", None),
    "GlobalPauseSignalsMinuteUTC": ("global_pause_minute", "int", None),
    "GlobalCloseAllHourUTC": ("global_close_hour", "int", None),
    "GlobalCloseAllMinuteUTC": ("global_close_minute", "int", None),
    "GlobalResumeSignalsHourUTC": ("global_resume_hour", "int", None),
    "GlobalResumeSignalsMinuteUTC": ("global_resume_minute", "int", None),
    "EnablePropfirmBacktestMode": ("enable_propfirm_backtest", "bool", None),
    "PropStrategyMode": ("prop_strategy_mode", "enum", "ENUM_PROP_STRATEGY_MODE"),
    "PropCustomStrategies": ("prop_custom_strategies", "string", None),
    "PropStartingBalance": ("prop_starting_balance", "float", None),
    "PropMaxTotalDrawdownPercent": ("prop_max_total_dd_percent", "float", None),
    "PropProfitTargetPercent": ("prop_profit_target_percent", "float", None),
    "PropEnableDailyDrawdown": ("prop_enable_daily_dd", "bool", None),
    "PropDailyDrawdownPercent": ("prop_daily_dd_percent", "float", None),
    "PropDailyProtectionBufferPercent": ("prop_daily_buffer_percent", "float", None),
    "PropDailyResetHourUTC": ("prop_daily_reset_hour", "int", None),
    "PropDailyResetMinuteUTC": ("prop_daily_reset_minute", "int", None),
    "PropPauseSignalsHourUTC": ("prop_pause_hour", "int", None),
    "PropPauseSignalsMinuteUTC": ("prop_pause_minute", "int", None),
    "PropCloseAllHourUTC": ("prop_close_hour", "int", None),
    "PropCloseAllMinuteUTC": ("prop_close_minute", "int", None),
    "PropResumeSignalsHourUTC": ("prop_resume_hour", "int", None),
    "PropResumeSignalsMinuteUTC": ("prop_resume_minute", "int", None),
    "PropRollingStartMode": ("prop_rolling_start", "bool", None),
    "PropSpawnInterval": ("prop_spawn_interval", "enum", "ENUM_PROP_SPAWN_INTERVAL"),
    "PropMaxStartDays": ("prop_max_start_days", "int", None),
    "PropHtmlReportFileName": ("prop_html_report_name", "string", None),
    "PropRecencyHalfLifeDays": ("prop_recency_half_life_days", "float", None),
    "ParallelMode": (None, "int", None),
    "ParallelNodeNumber": (None, "int", None),
    "ParallelTotalNodes": (None, "int", None),
    "ParallelSessionKey": (None, "string", None),
    "EnableCsvLog": ("enable_csv_log", "bool", None),
    "LogFileName": ("log_file_name", "string", None),
    "PrintDetailedLog": ("print_detailed_log", "bool", None),
    "EnableReceiverConnection": ("enable_receiver_connection", "bool", None),
    "ReceiverCopierKey": ("receiver_copier_key", "string", None),
    "ReceiverPollIntervalMs": ("receiver_poll_interval_ms", "int", None),
}

SET_FIELD_NAMES = {v[0]: k for k, v in SET_FIELD_MAP.items() if v[0] is not None}


def _detect_encoding(filepath: str) -> str:
    with open(filepath, "rb") as f:
        raw = f.read(4)
    if raw.startswith(codecs.BOM_UTF16_LE) or raw.startswith(codecs.BOM_UTF16_BE):
        return "utf-16"
    if raw.startswith(codecs.BOM_UTF8):
        return "utf-8-sig"
    return "utf-8"


def _parse_value_str(value_str: str, vtype: str, enum_name: Optional[str] = None) -> object:
    stripped = value_str.strip()
    if vtype == "bool":
        return stripped.lower() in ("true", "1", "yes")
    if vtype == "int":
        return int(stripped)
    if vtype == "enum" and enum_name:
        val = int(stripped)
        rev_map = ENUM_INT_TO_STRING.get(enum_name, {})
        return rev_map.get(val, stripped)
    if vtype == "float":
        return float(stripped)
    return stripped


def _format_value(value: object, vtype: str, enum_name: Optional[str] = None,
                  raw_str: Optional[str] = None) -> str:
    if raw_str is not None:
        return raw_str
    if vtype == "bool":
        return "true" if value else "false"
    if vtype == "enum" and enum_name and isinstance(value, str):
        fwd_map = ENUM_VALUE_MAP.get(enum_name, {})
        return str(fwd_map.get(value, value))
    if vtype == "float" and isinstance(value, float):
        s = str(value)
        if "." not in s:
            s += ".0"
        return s
    return str(value)


def easettings_to_set_lines(settings: EASettings, parallel_mode: int = 0,
                            node_number: int = 1, total_nodes: int = 1,
                            session_key: str = "",
                            raw_values: Optional[Dict[str, str]] = None) -> str:
    if raw_values is None:
        raw_values = {}
    lines = ["//--- input parameters"]
    for set_name, (model_field, vtype, enum_name) in SET_FIELD_MAP.items():
        if model_field is not None:
            value = getattr(settings, model_field)
            raw = raw_values.get(set_name)
            lines.append(f"{set_name}={_format_value(value, vtype, enum_name, raw)}")
        else:
            if set_name == "ParallelMode":
                lines.append(f"{set_name}={parallel_mode}")
            elif set_name == "ParallelNodeNumber":
                lines.append(f"{set_name}={node_number}")
            elif set_name == "ParallelTotalNodes":
                lines.append(f"{set_name}={total_nodes}")
            elif set_name == "ParallelSessionKey":
                lines.append(f"{set_name}={session_key}")
    return "\n".join(lines) + "\n"


def set_lines_to_easettings(lines: str, raw_values: Optional[Dict[str, str]] = None) -> EASettings:
    settings = EASettings()
    if raw_values is None:
        raw_values = {}
    for line in lines.splitlines():
        line = line.strip()
        if not line or line.startswith("//") or line.startswith("#"):
            continue
        if "=" not in line:
            continue
        set_name, value_str = line.split("=", 1)
        set_name = set_name.strip()
        value_str = value_str.strip()
        if set_name not in SET_FIELD_MAP:
            continue
        model_field, vtype, enum_name = SET_FIELD_MAP[set_name]
        if model_field is None:
            continue
        parsed = _parse_value_str(value_str, vtype, enum_name)
        setattr(settings, model_field, parsed)
        raw_values[set_name] = value_str
    return settings


def write_set_file(filepath: str, settings: EASettings, parallel_mode: int = 0,
                   node_number: int = 1, total_nodes: int = 1,
                   session_key: str = "",
                   raw_values: Optional[Dict[str, str]] = None) -> None:
    content = easettings_to_set_lines(settings, parallel_mode, node_number,
                                      total_nodes, session_key, raw_values)
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    with open(filepath, "w", encoding="utf-16") as f:
        f.write(content)


def read_set_file(filepath: str) -> tuple:
    encoding = _detect_encoding(filepath)
    with open(filepath, "r", encoding=encoding) as f:
        content = f.read()
    raw_values = {}
    settings = set_lines_to_easettings(content, raw_values)
    return settings, raw_values


def get_terminal_set_path(terminal_data_folder: str, ea_name: str = "HundredStrategyEA") -> str:
    tester_dir = os.path.join(terminal_data_folder, "MQL5", "Profiles", "Tester")
    return os.path.join(tester_dir, f"{ea_name}.set")


def get_common_files_path(terminal_data_folder: str) -> str:
    return os.path.join(terminal_data_folder, "Files", "Common")


def _parse_propx_tester_value(val: str, vtype: str, enum_name: Optional[str] = None) -> object:
    """Parse a single [TesterInputs] value (everything before first '||')."""
    stripped = val.strip()
    if "||" in stripped:
        stripped = stripped.split("||", 1)[0].strip()
    return _parse_value_str(stripped, vtype, enum_name)


def parse_propx_ini(filepath: str = PROPX_INI_PATH) -> Tuple[EASettings, BacktestConfig]:
    encoding = _detect_encoding(filepath)
    with open(filepath, "r", encoding=encoding) as f:
        content = f.read()

    settings = EASettings()
    bt_config = BacktestConfig()

    section = None
    for line in content.splitlines():
        line = line.strip()
        if not line or line.startswith(";"):
            continue
        if line.startswith("[") and line.endswith("]"):
            section = line[1:-1].strip()
            continue
        if "=" not in line:
            continue

        key, value_str = line.split("=", 1)
        key = key.strip()
        value_str = value_str.strip()

        if section == "Tester":
            if key == "Symbol":
                bt_config.symbol = value_str
            elif key == "Period":
                if value_str.upper() in TIMEFRAMES:
                    bt_config.timeframe = value_str.upper()
            elif key == "Model":
                try:
                    mid = int(value_str)
                    bt_config.model = MODEL_INT_TO_STR.get(mid, bt_config.model)
                except ValueError:
                    pass
            elif key == "Deposit":
                try:
                    bt_config.deposit = float(value_str)
                except ValueError:
                    pass

        elif section == "TesterInputs":
            if key not in SET_FIELD_MAP:
                continue
            model_field, vtype, enum_name = SET_FIELD_MAP[key]
            if model_field is None:
                continue
            parsed = _parse_propx_tester_value(value_str, vtype, enum_name)
            setattr(settings, model_field, parsed)

    return settings, bt_config
