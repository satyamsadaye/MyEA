import os
import re
import csv
from typing import Dict, List, Optional
from dataclasses import dataclass, field


@dataclass
class PartialResult:
    strategy_id: int
    strategy_name: str
    breached: bool
    passed: bool
    started: int
    ended: int
    balance: float
    equity: float
    max_drawdown: float
    max_profit: float
    days_to_target: int
    days_to_breach: int
    trades: int
    wins: int
    losses: int
    gross_profit: float
    gross_loss: float
    breach_reason: str


@dataclass
class MergeSession:
    session_key: str
    total_nodes: int
    rolling_mode: bool
    test_start: int = 0
    test_end: int = 0
    results: Dict[int, PartialResult] = field(default_factory=dict)
    signal_counts: Dict[int, int] = field(default_factory=dict)
    nodes_found: List[int] = field(default_factory=list)


def find_partial_files(common_dirs: List[str], session_key: str) -> Dict[int, str]:
    found = {}
    for common_dir in common_dirs:
        if not os.path.isdir(common_dir):
            continue
        pattern = re.compile(rf"Partial_{re.escape(session_key)}_Node(\d+)\.csv")
        for fname in os.listdir(common_dir):
            m = pattern.match(fname)
            if m:
                node = int(m.group(1))
                found[node] = os.path.join(common_dir, fname)
    return found


def parse_partial_line(line: str, rolling: bool) -> Optional[PartialResult]:
    line = line.strip()
    if rolling:
        if not line.startswith("R|"):
            return None
        parts = line.split("|")
        if len(parts) < 31:
            return None
        return PartialResult(
            strategy_id=int(parts[1]),
            strategy_name=parts[2],
            breached=parts[5] == "1",
            passed=parts[6] == "1",
            started=int(parts[3]) if parts[3] else 0,
            ended=int(parts[4]) if parts[4] else 0,
            balance=float(parts[11]) if parts[11] else 0.0,
            equity=float(parts[12]) if parts[12] else 0.0,
            max_drawdown=float(parts[15]) if parts[15] else 0.0,
            max_profit=float(parts[16]) if parts[16] else 0.0,
            days_to_target=int(parts[19]) if parts[19] else 0,
            days_to_breach=int(parts[20]) if parts[20] else 0,
            trades=int(parts[22]) if parts[22] else 0,
            wins=int(parts[23]) if parts[23] else 0,
            losses=int(parts[24]) if parts[24] else 0,
            gross_profit=float(parts[17]) if parts[17] else 0.0,
            gross_loss=float(parts[18]) if parts[18] else 0.0,
            breach_reason=parts[8],
        )
    else:
        if not line.startswith("S|"):
            return None
        parts = line.split("|")
        if len(parts) < 30:
            return None
        return PartialResult(
            strategy_id=int(parts[1]),
            strategy_name=parts[2],
            breached=parts[3] == "1",
            passed=parts[4] == "1",
            started=int(parts[5]) if parts[5] else 0,
            ended=int(parts[6]) if parts[6] else 0,
            balance=float(parts[7]) if parts[7] else 0.0,
            equity=float(parts[8]) if parts[8] else 0.0,
            max_drawdown=float(parts[10]) if parts[10] else 0.0,
            max_profit=float(parts[11]) if parts[11] else 0.0,
            days_to_target=int(parts[12]) if parts[12] else 0,
            days_to_breach=int(parts[13]) if parts[13] else 0,
            trades=int(parts[15]) if parts[15] else 0,
            wins=int(parts[16]) if parts[16] else 0,
            losses=int(parts[17]) if parts[17] else 0,
            gross_profit=float(parts[21]) if parts[21] else 0.0,
            gross_loss=float(parts[22]) if parts[22] else 0.0,
            breach_reason=parts[24],
        )


def merge_partial_files(common_dirs: List[str], session_key: str,
                        total_nodes: int) -> MergeSession:
    session = MergeSession(
        session_key=session_key,
        total_nodes=total_nodes,
        rolling_mode=True,
    )
    partial_files = find_partial_files(common_dirs, session_key)

    for node in sorted(partial_files.keys()):
        filepath = partial_files[node]
        session.nodes_found.append(node)
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            rolling_mode = True
            for line in f:
                line = line.strip()
                if not line:
                    continue
                if line.startswith("#ROLLING_MODE "):
                    val = line.split(" ", 1)[1].strip()
                    rolling_mode = val != "0"
                    session.rolling_mode = rolling_mode
                elif line.startswith("#TEST_START "):
                    session.test_start = int(line.split(" ", 1)[1].strip())
                elif line.startswith("#TEST_END "):
                    te = int(line.split(" ", 1)[1].strip())
                    if te > session.test_end:
                        session.test_end = te
                elif line.startswith("#SIGNALS"):
                    data = line[8:].strip()
                    for pair in data.split():
                        if ";" in pair:
                            sid, cnt = pair.split(";", 1)
                            session.signal_counts[int(sid)] = int(cnt)
                elif line.startswith("R|") or line.startswith("S|"):
                    pr = parse_partial_line(line, rolling_mode)
                    if pr and pr.strategy_id not in session.results:
                        session.results[pr.strategy_id] = pr

    return session


def generate_merged_csv(session: MergeSession, output_path: str) -> str:
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    with open(output_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow([
            "StrategyID", "StrategyName", "Breached", "Passed",
            "Started", "Ended", "Balance", "Equity",
            "MaxDrawdown", "MaxProfit", "DaysToTarget", "DaysToBreach",
            "Trades", "Wins", "Losses", "GrossProfit", "GrossLoss",
            "BreachReason", "SignalCount"
        ])
        for sid in sorted(session.results.keys()):
            r = session.results[sid]
            sc = session.signal_counts.get(sid, 0)
            writer.writerow([
                r.strategy_id, r.strategy_name, r.breached, r.passed,
                r.started, r.ended, r.balance, r.equity,
                r.max_drawdown, r.max_profit, r.days_to_target, r.days_to_breach,
                r.trades, r.wins, r.losses, r.gross_profit, r.gross_loss,
                r.breach_reason, sc,
            ])
    return output_path
