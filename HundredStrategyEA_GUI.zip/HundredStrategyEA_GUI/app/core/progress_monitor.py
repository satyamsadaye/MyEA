import os
import time
import threading
import re
from typing import Dict, Optional, Callable
from .settings_model import TerminalStatus


class ProgressMonitor:
    def __init__(self, common_paths: Dict[int, str], session_key: str, total_nodes: int):
        self.common_paths = common_paths
        self.session_key = session_key
        self.total_nodes = total_nodes
        self._statuses: Dict[int, TerminalStatus] = {}
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()
        self._on_update: Optional[Callable] = None
        self._processes: Dict[int, int] = {}

    def set_process_pid(self, node: int, pid: int):
        with self._lock:
            self._processes[node] = pid

    def set_on_update(self, callback: Callable):
        self._on_update = callback

    def update_status(self, node: int, status: TerminalStatus):
        with self._lock:
            self._statuses[node] = status

    def start(self):
        self._running = True
        self._thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self._thread.start()

    def stop(self):
        self._running = False
        if self._thread:
            self._thread.join(timeout=2.0)

    def get_status(self, node: int) -> Optional[TerminalStatus]:
        with self._lock:
            return self._statuses.get(node)

    def get_all_statuses(self) -> Dict[int, TerminalStatus]:
        with self._lock:
            return dict(self._statuses)

    def all_complete(self) -> bool:
        with self._lock:
            if len(self._statuses) < self.total_nodes:
                return False
            for st in self._statuses.values():
                if st.status not in ("Complete", "Error"):
                    return False
            return True

    def any_error(self) -> bool:
        with self._lock:
            return any(s.status == "Error" for s in self._statuses.values())

    def _detect_partial_file(self, node: int) -> bool:
        path = self.common_paths.get(node)
        if not path:
            return False
        partial_file = os.path.join(path, f"Partial_{self.session_key}_Node{node}.csv")
        return os.path.isfile(partial_file) and os.path.getsize(partial_file) > 100

    def _monitor_loop(self):
        start_time = time.time()
        while self._running:
            time.sleep(1.0)
            changed = False
            with self._lock:
                for node in range(1, self.total_nodes + 1):
                    if node not in self._statuses:
                        self._statuses[node] = TerminalStatus(
                            node_number=node,
                            path=self.common_paths.get(node, ""),
                            status="Waiting",
                        )
                    st = self._statuses[node]
                    if st.status in ("Complete", "Error", "Waiting"):
                        continue
                    st.elapsed_seconds = int(time.time() - start_time)
                    if st.status == "Running" and self._detect_partial_file(node):
                        st.status = "Complete"
                        st.progress = 100.0
                    changed = True
            if self._on_update and changed:
                self._on_update()
