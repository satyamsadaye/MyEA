import os
import glob
import re
from typing import List
from .settings_model import TerminalConfig


MT5_EXE_NAMES = ["terminal64.exe", "terminal.exe"]

COMMON_SEARCH_PATHS = [
    r"C:\Program Files\MetaTrader 5*",
    r"C:\Program Files (x86)\MetaTrader 5*",
    r"C:\Program Files\MetaTrader 5*",
    r"D:\Program Files\MetaTrader 5*",
    r"C:\Users\*\Desktop\*\terminal*",
    r"C:\*\terminal*",
    r"D:\*\terminal*",
]


def find_portable_data_folders() -> List[str]:
    results = []
    for search_pattern in COMMON_SEARCH_PATHS:
        matches = glob.glob(search_pattern, recursive=False)
        for match in matches:
            if os.path.isdir(match):
                data_dir = os.path.join(match, "MQL5")
                if os.path.isdir(data_dir):
                    results.append(match)
    return results


def find_terminals_custom(paths: List[str]) -> List[TerminalConfig]:
    found = []
    seen = set()
    for p in paths:
        p = p.strip()
        if not p:
            continue
        if os.path.isfile(p) and p.lower().endswith((".exe")):
            folder = os.path.dirname(p)
            if folder not in seen:
                seen.add(folder)
                tc = TerminalConfig(path=p, data_folder=_resolve_data_folder(p, folder))
                found.append(tc)
        elif os.path.isdir(p):
            for exe_name in MT5_EXE_NAMES:
                exe_path = os.path.join(p, exe_name)
                if os.path.isfile(exe_path):
                    if p not in seen:
                        seen.add(p)
                        tc = TerminalConfig(path=exe_path, data_folder=_resolve_data_folder(exe_path, p))
                        found.append(tc)
                    break
    for i, tc in enumerate(found):
        tc.node_number = i + 1
    return found


def _resolve_data_folder(exe_path: str, folder: str) -> str:
    common_dirs = [
        os.path.join(folder, "Data"),
        os.path.join(folder, "Bases"),
        folder,
    ]
    for d in common_dirs:
        mql5_dir = os.path.join(d, "MQL5")
        if os.path.isdir(mql5_dir):
            return d
        profiles_dir = os.path.join(d, "Profiles")
        if os.path.isdir(profiles_dir):
            return d
    return folder


def auto_discover_terminals() -> List[TerminalConfig]:
    found = []
    seen_folders = set()

    for exe_name in MT5_EXE_NAMES:
        for drive in "CDEFGH":
            search = f"{drive}:\\**\\{exe_name}"
            try:
                matches = glob.glob(search, recursive=True)
                for match in matches:
                    folder = os.path.dirname(match)
                    if folder not in seen_folders:
                        seen_folders.add(folder)
                        data = _resolve_data_folder(match, folder)
                        found.append(TerminalConfig(path=match, data_folder=data))
            except Exception:
                pass

    for i, tc in enumerate(found):
        tc.node_number = i + 1
    return found
