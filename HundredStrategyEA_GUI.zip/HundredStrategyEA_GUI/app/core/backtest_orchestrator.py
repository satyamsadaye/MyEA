import os
import time
import threading
from datetime import datetime
from typing import List, Dict, Optional, Callable
from .settings_model import EASettings, TerminalConfig, BacktestConfig, TerminalStatus
from .ea_config_manager import (
    easettings_to_set_lines, get_terminal_set_path, get_common_files_path
)
from .progress_monitor import ProgressMonitor
from .mt5_automation import create_controller


class BacktestOrchestrator:
    def __init__(self):
        self._controllers: Dict[int, object] = {}
        self._monitor: Optional[ProgressMonitor] = None
        self.session_key: str = ""
        self._running = False
        self._stop_requested = False

    @property
    def monitor(self) -> Optional[ProgressMonitor]:
        return self._monitor

    def _generate_session_key(self) -> str:
        now = datetime.now()
        return f"bt{now.strftime('%Y%m%d_%H%M%S')}"

    def _get_common_dirs(self, terminals: List[TerminalConfig]) -> Dict[int, str]:
        return {tc.node_number: get_common_files_path(tc.data_folder) for tc in terminals}

    def launch_backtests(self, settings: EASettings, terminals: List[TerminalConfig],
                         backtest_cfg: BacktestConfig,
                         on_update: Optional[Callable] = None) -> bool:
        if self._running:
            return False
        self._running = True
        self._stop_requested = False
        self.session_key = self._generate_session_key()
        total_nodes = len(terminals)

        for tc in terminals:
            settings.prop_html_report_name = f"Propfirm_100_Strategy_Report_{self.session_key}.html"

        config_strs = {}
        for tc in terminals:
            cfg_lines = easettings_to_set_lines(
                settings, parallel_mode=1,
                node_number=tc.node_number,
                total_nodes=total_nodes,
                session_key=self.session_key
            )
            config_strs[tc.node_number] = cfg_lines

        for tc in terminals:
            set_path = get_terminal_set_path(tc.data_folder)
            os.makedirs(os.path.dirname(set_path), exist_ok=True)
            with open(set_path, "w", encoding="utf-8") as f:
                f.write(config_strs[tc.node_number])

        common_dirs = self._get_common_dirs(terminals)
        self._monitor = ProgressMonitor(common_dirs, self.session_key, total_nodes)
        self._monitor.set_on_update(on_update)
        self._monitor.start()

        launched_any = False
        for tc in terminals:
            exe_path = tc.path
            if not os.path.isfile(exe_path):
                if self._monitor:
                    ts = TerminalStatus(
                        node_number=tc.node_number, path=exe_path,
                        status="Error", error="Terminal exe not found"
                    )
                    self._monitor.update_status(tc.node_number, ts)
                continue
            launched_any = True
            threading.Thread(
                target=self._launch_and_control_one,
                args=(settings, backtest_cfg, tc, total_nodes),
                daemon=True
            ).start()

        if not launched_any:
            self._running = False
            if self._monitor:
                self._monitor.stop()
            return False
        return True

    def _launch_and_control_one(self, settings: EASettings, backtest_cfg: BacktestConfig,
                                 tc: TerminalConfig, total_nodes: int):
        try:
            ctrl = create_controller(tc.path, tc.node_number)
            if ctrl is None:
                self._update_status(tc.node_number, "Error", "No automation available")
                return

            self._controllers[tc.node_number] = ctrl
            self._update_status(tc.node_number, "Starting Terminal")

            ok = ctrl.launch_and_wait(timeout=90.0)
            if not ok:
                self._update_status(tc.node_number, "Error", ctrl.error or "Launch failed")
                return

            self._update_status(tc.node_number, "Configuring Tester")
            if self._monitor:
                self._monitor.set_process_pid(tc.node_number, ctrl.pid)

            ctrl.open_tester()
            time.sleep(2.0)

            if self._stop_requested:
                ctrl.stop()
                return

            self._update_status(tc.node_number, "Starting Test")
            ctrl.click_start()
            self._update_status(tc.node_number, "Running")

            def on_progress():
                if self._stop_requested:
                    ctrl.stop()
                if self._monitor:
                    ts = self._monitor.get_status(tc.node_number)
                    if ts:
                        ts.progress = ctrl.progress
                        import psutil
                        try:
                            proc = psutil.Process(ctrl.pid)
                            ts.cpu_percent = proc.cpu_percent(interval=0.0)
                            ts.memory_mb = proc.memory_info().rss / (1024 * 1024)
                        except Exception:
                            pass

            ctrl.monitor_progress(on_status=on_progress)

            self._update_status(tc.node_number,
                                "Complete" if ctrl.status == "Complete" else "Error",
                                ctrl.error if ctrl.status == "Error" else "")
            if self._monitor:
                ts = self._monitor.get_status(tc.node_number)
                if ts:
                    ts.progress = 100.0 if ctrl.status == "Complete" else ts.progress

        except Exception as e:
            self._update_status(tc.node_number, "Error", str(e))

    def _update_status(self, node: int, status: str, error: str = ""):
        if self._monitor:
            ts = self._monitor.get_status(node)
            if ts:
                ts.status = status
                ts.error = error
            else:
                self._monitor.update_status(node, TerminalStatus(
                    node_number=node, path="", status=status, error=error
                ))

    def stop_all(self):
        self._stop_requested = True
        self._running = False
        if self._monitor:
            self._monitor.stop()
        for node, ctrl in self._controllers.items():
            try:
                ctrl.stop()
            except Exception:
                pass
        self._controllers.clear()

    def all_complete(self) -> bool:
        if not self._monitor or not self._controllers:
            return False
        for node, ctrl in self._controllers.items():
            if ctrl.status not in ("Complete", "Error"):
                return False
        return True

    def any_error(self) -> bool:
        if not self._monitor:
            return False
        for node, ctrl in self._controllers.items():
            if ctrl.status == "Error":
                return True
        return False

    def cleanup(self):
        self.stop_all()

    def reset_settings(self, settings: EASettings, terminals: List[TerminalConfig]):
        for tc in terminals:
            set_path = get_terminal_set_path(tc.data_folder)
            cfg_lines = easettings_to_set_lines(
                settings, parallel_mode=0,
                node_number=1, total_nodes=1, session_key=""
            )
            os.makedirs(os.path.dirname(set_path), exist_ok=True)
            with open(set_path, "w", encoding="utf-8") as f:
                f.write(cfg_lines)
