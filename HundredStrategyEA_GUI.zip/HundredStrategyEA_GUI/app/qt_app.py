import sys
import os
import traceback
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QWidget,
    QMessageBox, QStatusBar, QSplitter, QHBoxLayout, QGroupBox,
    QFileDialog, QPushButton
)
from PyQt6.QtCore import Qt, QTimer

from .core.settings_model import EASettings, TerminalConfig, BacktestConfig
from .core.backtest_orchestrator import BacktestOrchestrator
from .core.result_merger import merge_partial_files, generate_merged_csv
from .core.ea_config_manager import get_common_files_path, parse_propx_ini, PROPX_INI_PATH
from .widgets.ea_settings_widget import EASettingsWidget
from .widgets.terminal_config_widget import TerminalConfigWidget
from .widgets.backtest_config_widget import BacktestConfigWidget
from .widgets.run_control_widget import RunControlWidget
from .widgets.settings_saver import save_session, load_session


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("HundredStrategyEA Backtest Controller")
        self.resize(1100, 800)

        self._orchestrator = BacktestOrchestrator()
        self._running = False
        self._update_timer = QTimer()
        self._update_timer.setInterval(1000)
        self._update_timer.timeout.connect(self._poll_progress)

        self._init_ui()
        self._load_saved_state()

    def _init_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QVBoxLayout(central)

        splitter = QSplitter(Qt.Orientation.Vertical)

        top_widget = QWidget()
        top_layout = QHBoxLayout(top_widget)
        top_layout.setContentsMargins(0, 0, 0, 0)

        left_panel = QWidget()
        left_layout = QVBoxLayout(left_panel)
        left_layout.setContentsMargins(0, 0, 0, 0)
        term_group = QGroupBox("Terminal Configuration")
        term_layout = QVBoxLayout(term_group)
        self._terminal_widget = TerminalConfigWidget()
        term_layout.addWidget(self._terminal_widget)
        left_layout.addWidget(term_group)

        bt_group = QGroupBox("Backtest Configuration")
        bt_layout = QVBoxLayout(bt_group)
        self._bt_config_widget = BacktestConfigWidget()
        bt_layout.addWidget(self._bt_config_widget)
        left_layout.addWidget(bt_group)
        left_layout.addStretch()

        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        right_layout.setContentsMargins(0, 0, 0, 0)
        ea_group = QGroupBox("EA Settings")
        ea_layout = QVBoxLayout(ea_group)
        self._ea_settings_widget = EASettingsWidget()
        ea_layout.addWidget(self._ea_settings_widget)
        right_layout.addWidget(ea_group)

        splitter.addWidget(left_panel)
        splitter.addWidget(right_panel)
        splitter.setSizes([400, 600])
        main_layout.addWidget(splitter)

        toolbar_layout = QHBoxLayout()
        self._propx_btn = QPushButton("Load Propx Defaults")
        self._propx_btn.clicked.connect(self._load_propx_defaults)
        toolbar_layout.addWidget(self._propx_btn)
        toolbar_layout.addStretch()

        self._run_widget = RunControlWidget()
        self._run_widget.run_requested.connect(self._on_run)
        self._run_widget.stop_requested.connect(self._on_stop)
        self._run_widget.merge_requested.connect(self._on_merge)
        main_layout.addLayout(toolbar_layout)
        main_layout.addWidget(self._run_widget)

        self._status_bar = QStatusBar()
        self.setStatusBar(self._status_bar)

    def _load_propx_defaults(self):
        try:
            settings, bt_cfg = parse_propx_ini(PROPX_INI_PATH)
            self._ea_settings_widget._raw_values = {}
            self._ea_settings_widget.set_settings(settings)
            self._bt_config_widget.set_config(bt_cfg)
            self._status_bar.showMessage("Loaded defaults from propx.ini", 5000)
        except Exception as e:
            QMessageBox.critical(self, "Load Error",
                                 f"Failed to load propx.ini:\n{e}")

    def _load_saved_state(self):
        try:
            settings, bt_cfg = parse_propx_ini(PROPX_INI_PATH)
            self._ea_settings_widget._raw_values = {}
            self._ea_settings_widget.set_settings(settings)
            self._bt_config_widget.set_config(bt_cfg)
        except Exception:
            pass
        try:
            terminals, settings, bt_cfg, active_count = load_session()
            if terminals:
                self._terminal_widget.set_terminals(terminals)
                self._terminal_widget._count_spin.setValue(active_count)
            if settings:
                self._ea_settings_widget.set_settings(settings)
            if bt_cfg:
                self._bt_config_widget.set_config(bt_cfg)
        except Exception:
            pass

    def _on_run(self):
        if self._running:
            return

        terminals = self._terminal_widget.terminals()
        if len(terminals) < 2:
            QMessageBox.warning(self, "Minimum Terminals",
                                "You need at least 2 terminals for parallel backtesting.")
            return

        settings = self._ea_settings_widget.settings()
        bt_cfg = self._bt_config_widget.config()

        save_session(
            self._terminal_widget.all_terminals(),
            settings, bt_cfg,
            self._terminal_widget._count_spin.value()
        )

        self._running = True
        self._run_widget.set_running_state(True)
        self._run_widget.reset()
        self._run_widget.log_message("Starting backtest...")
        self._status_bar.showMessage("Starting terminals...")

        try:
            ok = self._orchestrator.launch_backtests(
                settings, terminals, bt_cfg,
                on_update=self._on_progress_update
            )
        except Exception as e:
            tb = traceback.format_exc()
            self._run_widget.log_message(f"ERROR: {e}")
            self._run_widget.log_message(tb)
            self._running = False
            self._run_widget.set_running_state(False)
            self._status_bar.showMessage("Launch failed!", 5000)
            QMessageBox.critical(self, "Launch Error", f"Failed to launch backtest:\n{e}")
            return

        if not ok:
            self._running = False
            self._run_widget.set_running_state(False)
            self._run_widget.log_message("ERROR: No terminals could be launched.")
            self._status_bar.showMessage("No terminals launched!", 5000)
            return

        self._run_widget.set_session_key(self._orchestrator.session_key)
        self._run_widget.log_message(f"Session key: {self._orchestrator.session_key}")
        self._run_widget.log_message(f"Launched {len(terminals)} terminal(s)")
        self._status_bar.showMessage("Backtest running...")
        self._update_timer.start()

    def _on_stop(self):
        self._run_widget.log_message("Stopping all terminals...")
        self._status_bar.showMessage("Stopping...")
        self._orchestrator.stop_all()
        self._update_timer.stop()
        self._running = False
        self._run_widget.set_running_state(False)
        self._run_widget.log_message("Backtest stopped by user.")
        self._status_bar.showMessage("Stopped", 5000)

    def _on_merge(self):
        terminals = self._terminal_widget.terminals()
        if not terminals:
            return
        if not self._orchestrator.session_key:
            QMessageBox.warning(self, "No Session", "No completed backtest session to merge.")
            return

        common_dirs = list(set(
            get_common_files_path(tc.data_folder) for tc in terminals
        ))

        self._run_widget.log_message("Merging partial results...")
        self._status_bar.showMessage("Merging...")
        try:
            session = merge_partial_files(
                common_dirs,
                self._orchestrator.session_key,
                len(terminals)
            )
            report_dir = os.path.join(
                os.path.dirname(os.path.dirname(__file__)), "reports"
            )
            os.makedirs(report_dir, exist_ok=True)
            csv_path = os.path.join(
                report_dir,
                f"merged_results_{self._orchestrator.session_key}.csv"
            )
            generate_merged_csv(session, csv_path)
            self._run_widget.log_message(
                f"Merged {len(session.results)} strategies from "
                f"{len(session.nodes_found)} node(s)"
            )
            self._run_widget.log_message(f"CSV report: {csv_path}")

            settings = self._ea_settings_widget.settings()
            self._orchestrator.reset_settings(settings, terminals)
            self._run_widget.log_message("Settings restored to base (ParallelMode=0).")

            self._status_bar.showMessage("Merge complete!", 5000)
            QMessageBox.information(
                self, "Merge Complete",
                f"Merged {len(session.results)} strategies.\n"
                f"Report saved to:\n{csv_path}\n\n"
                f"Settings have been restored to base configuration."
            )
        except Exception as e:
            tb = traceback.format_exc()
            self._run_widget.log_message(f"Merge failed: {e}")
            self._run_widget.log_message(tb)
            self._status_bar.showMessage("Merge failed!", 5000)
            QMessageBox.critical(self, "Merge Error", str(e))

    def _on_progress_update(self):
        pass

    def _poll_progress(self):
        if not self._orchestrator.monitor:
            return
        try:
            statuses = self._orchestrator.monitor.get_all_statuses()
            if not statuses:
                return
            self._run_widget.update_statuses(statuses)

            if self._orchestrator.all_complete():
                self._update_timer.stop()
                self._running = False
                self._run_widget.set_running_state(False)
                self._run_widget.log_message("All terminals completed!")
                self._run_widget.enable_merge(True)
                self._status_bar.showMessage("All terminals complete. Ready to merge.", 10000)
            elif self._orchestrator.any_error():
                self._run_widget.log_message("One or more terminals encountered errors.")
        except Exception as e:
            self._run_widget.log_message(f"Poll error: {e}")

    def closeEvent(self, event):
        if self._running:
            reply = QMessageBox.question(
                self, "Quit?",
                "Backtest is running. Stop and quit?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if reply == QMessageBox.StandardButton.No:
                event.ignore()
                return
            self._orchestrator.stop_all()
        try:
            save_session(
                self._terminal_widget.all_terminals(),
                self._ea_settings_widget.settings(),
                self._bt_config_widget.config(),
                self._terminal_widget._count_spin.value()
            )
        except Exception:
            pass
        event.accept()
