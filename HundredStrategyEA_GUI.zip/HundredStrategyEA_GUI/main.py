#!/usr/bin/env python3
"""
HundredStrategyEA Backtest Automation GUI

A PyQt6-based desktop application for orchestrating parallel backtesting
of the HundredStrategyEA across multiple MetaTrader 5 terminals.

Usage:
    python main.py

Requirements:
    PyQt6, psutil, pywin32 (Windows only)
"""

import sys
import os
from PyQt6.QtWidgets import QApplication
from PyQt6.QtCore import Qt


def main():
    if sys.platform != "win32":
        print("WARNING: MetaTrader 5 runs on Windows only.")
        print("This GUI is designed for Windows. Some features may not work.")

    app = QApplication(sys.argv)
    app.setOrganizationName("Opencode")
    app.setApplicationName("HundredStrategyEA Backtest Controller")

    from app.qt_app import MainWindow
    window = MainWindow()
    window.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
