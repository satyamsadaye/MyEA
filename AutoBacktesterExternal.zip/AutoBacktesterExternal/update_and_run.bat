@echo off
title HundredStrategyEA — Update & Run
cd /d "%~dp0"

REM === PASTE YOUR LATEST ANI/SET FILE PATH BELOW ===
REM Change this line to point to your latest .set file from MT5:
set MY_ANI_FILE=C:\Users\Satyam.RAJ.001\Desktop\newfile.ini

REM === DO NOT EDIT BELOW THIS LINE ===
echo.
echo Copying "%MY_ANI_FILE%" to loopsetfile.ini...
copy /Y "%MY_ANI_FILE%" loopsetfile.ini >nul
if %errorlevel% neq 0 (
    echo ERROR: File not found! Check the path above.
    echo.
    pause
    exit /b 1
)
echo Done. Starting loop...
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "auto_backtest_loop.ps1"
pause
