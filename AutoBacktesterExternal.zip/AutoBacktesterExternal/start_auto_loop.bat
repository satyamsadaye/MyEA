@echo off
title HundredStrategyEA Auto Loop
cd /d "%~dp0"
echo Starting auto backtest loop...
echo Press Ctrl+C to stop.
echo You can close this window at any time — the test runs headlessly.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "auto_backtest_loop.ps1"
echo.
echo Script exited. Press any key to close.
pause >nul
