param(
    [int]$WarmUpSeconds = 30,
    [string]$ConfigPath = "",
    [string]$TesterIniPath = "$env:TEMP\auto_backtest_tester.ini"
)

$terminalPath = "C:\Program Files\MetaTrader 5\terminal64.exe"
$expertName = "t1.ex5"
$terminalIni = "$env:APPDATA\MetaQuotes\Terminal\D0E8209F77C8CF37AD8BF550E51FF075\config\terminal.ini"
$defaultSetFile = "C:\Users\Satyam.RAJ.001\Desktop\loopsetfile.ini"

# Auto-detect latest .set/.ani file on Desktop if no ConfigPath specified
if (-not $ConfigPath) {
    $latest = Get-ChildItem "$env:USERPROFILE\Desktop\*" -Include "*.set", "*.ani" -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending |
        Select-Object -First 1
    if ($latest) {
        $ConfigPath = $latest.FullName
        Write-Host "Auto-detected: $ConfigPath" -ForegroundColor Cyan
    }
    elseif (Test-Path $defaultSetFile) {
        $ConfigPath = $defaultSetFile
        Write-Host "Using default: $ConfigPath" -ForegroundColor Cyan
    }
    else {
        Write-Host "No .set file found. Use -ConfigPath to specify one." -ForegroundColor Red
        exit 1
    }
}

Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  HundredStrategyEA Auto Backtest Loop" -ForegroundColor Cyan
Write-Host "  Warm-up: ${WarmUpSeconds}s between runs" -ForegroundColor Cyan
Write-Host "  MT5: $terminalPath" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

function New-TesterIni {
    param([string]$SourceSetPath)

    if ($SourceSetPath -and (Test-Path $SourceSetPath)) {
        $ini = Get-Content $SourceSetPath -Encoding Unicode
    }
    else {
        Write-Host "No source .set file provided or not found. Using default settings." -ForegroundColor Yellow
        Write-Host "To customize: save your tester settings from MT5 GUI, then pass the path:" -ForegroundColor Yellow
        Write-Host "  .\auto_backtest_loop.ps1 -ConfigPath ""C:\path\to\your_settings.set""" -ForegroundColor Yellow
        Write-Host ""

        $ini = @(
            "[Tester]",
            "Expert=$expertName",
            "Symbol=BTCUSDm",
            "Period=M1",
            "Optimization=0",
            "Model=0",
            "FromDate=2026.07.10",
            "ToDate=2026.07.15",
            "ForwardMode=0",
            "Deposit=5000",
            "Currency=USD",
            "ProfitInPips=0",
            "Leverage=1000",
            "ExecutionMode=0",
            "OptimizationCriterion=0",
            "Visual=0",
            "",
            "[TesterInputs]",
            "EnablePropfirmBacktestMode=true||false||0||true||N",
            "PropRollingStartMode=true||false||0||true||N",
            "PropSpawnInterval=1||0||0||-30||N",
            "PropMaxStartDays=0||0||1||10||N",
            "PropHtmlReportFileName=Propfirm_1000_Strategy_Report.html",
            "PropStartingBalance=5000.0||5000.0||500.000000||50000.000000||N",
            "PropMaxTotalDrawdownPercent=6.0||6.0||0.600000||60.000000||N",
            "PropProfitTargetPercent=10.0||10.0||1.000000||100.000000||N",
            "PropEnableDailyDrawdown=true||false||0||true||N",
            "PropDailyDrawdownPercent=4.0||4.0||0.400000||40.000000||N",
            "PropDailyProtectionBufferPercent=1.0||1.0||0.100000||10.000000||N",
            "PropRecencyHalfLifeDays=14.0||14.0||1.400000||140.000000||N",
            "ParallelMode=0||0||1||10||N",
            "ParallelNodeNumber=1||1||1||10||N",
            "ParallelTotalNodes=2||2||1||20||N",
            "ParallelSessionKey=prop",
            "EnableCsvLog=false||false||0||true||N",
            "PrintDetailedLog=true||false||0||true||N"
        )
    }

    # Insert ShutdownTerminal=1 right after the last line of [Tester] section
    # Find the [Tester] section and add ShutdownTerminal before the next section or end
    $result = @()
    $inTester = $false
    $addedShutdown = $false

    foreach ($line in $ini) {
        if ($line -match '^\[Tester\]$') {
            $inTester = $true
            $result += $line
            continue
        }

        if ($inTester -and $line -match '^\[.+') {
            # We're leaving [Tester] — add ShutdownTerminal if not present
            if (-not $addedShutdown) {
                $result += "ShutdownTerminal=1"
                $addedShutdown = $true
            }
            $inTester = $false
        }

        if ($inTester -and $line.Trim() -eq '') {
            # Skip blank lines inside [Tester]
            continue
        }

        if ($inTester -and $line -match '^ShutdownTerminal') {
            # Replace existing with our value
            $result += "ShutdownTerminal=1"
            $addedShutdown = $true
            continue
        }

        $result += $line
    }

    if (-not $addedShutdown) {
        $result += "ShutdownTerminal=1"
    }

    # Remove any trailing blank lines
    while ($result.Count -gt 0 -and $result[-1].Trim() -eq '') {
        $result = $result[0..($result.Count - 2)]
    }

    $result | Set-Content -Path $TesterIniPath -Encoding Unicode
    Write-Host "Tester config written to: $TesterIniPath" -ForegroundColor Gray
    return $TesterIniPath
}

function Fix-TerminalIni {
    # terminal.ini caches the last tester Expert path and overrides /config:
    # We must clear its [Tester] Expert setting before each launch
    if (-not (Test-Path $terminalIni)) { return }

    $bytes = [System.IO.File]::ReadAllBytes($terminalIni)
    $content = [System.Text.Encoding]::Unicode.GetString($bytes)
    $original = $content

    # Split into sections and rebuild without [Tester]
    $lines = $content -split "`r`n|`n"
    $result = @()
    $inTester = $false
    foreach ($line in $lines) {
        if ($line -match '^\[Tester\]$') {
            $inTester = $true
            continue
        }
        if ($inTester -and $line -match '^\[.+') {
            $inTester = $false
            # fall through to include this section header
        }
        if (-not $inTester) {
            $result += $line
        }
    }
    $content = $result -join "`r`n"

    if ($content -ne $original) {
        [System.IO.File]::WriteAllBytes($terminalIni, [System.Text.Encoding]::Unicode.GetBytes($content))
        Write-Host "  Fixed terminal.ini (cleared cached [Tester] section)" -ForegroundColor Gray
    }
}

function Wait-ForTerminalExit {
    param([string]$ConfigPath)

    Write-Host "[$(Get-Date -Format 'HH:mm:ss')] Launching MT5 tester..." -ForegroundColor Green
    Write-Host "  Config: $ConfigPath" -ForegroundColor Gray

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $terminalPath
    $psi.Arguments = "/config:`"$ConfigPath`""
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true

    $proc = [System.Diagnostics.Process]::Start($psi)

    Write-Host "  PID: $($proc.Id)" -ForegroundColor Gray
    Write-Host "  Waiting for test to complete (terminal will auto-close)..." -ForegroundColor Yellow

    $proc.WaitForExit()

    Write-Host "[$(Get-Date -Format 'HH:mm:ss')] Test finished." -ForegroundColor Green
    Write-Host "  Exit code: $($proc.ExitCode)" -ForegroundColor Gray
}

# Main loop
$cycleNumber = 0
while ($true) {
    $cycleNumber++
    Write-Host ""
    Write-Host "----------- Cycle #$cycleNumber -----------" -ForegroundColor Magenta

    $iniFile = New-TesterIni -SourceSetPath $ConfigPath
    Fix-TerminalIni
    Wait-ForTerminalExit -ConfigPath $iniFile

    Write-Host "[$(Get-Date -Format 'HH:mm:ss')] Warm-up: waiting ${WarmUpSeconds}s before next run..." -ForegroundColor Cyan
    Start-Sleep -Seconds $WarmUpSeconds
}
