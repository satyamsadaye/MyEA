@echo off
echo Creating stop flag to gracefully stop the tester loop...
echo. > "%USERPROFILE%\Desktop\tester_stop.flag"
echo Done. The tester loop will stop after the current test completes.
echo (You may need to wait up to 30s for it to pick up the flag.)
pause
