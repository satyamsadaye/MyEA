@echo off
setlocal enabledelayedexpansion

title Intel Strategy Tester - Live Progress
cd /d "%~dp0"

:: =========================== CONFIGURATION ===========================
set "TERMINAL=C:\Program Files\MetaTrader 52\terminal64.exe"
set "INI_FILE=C:\Users\Satyam\Desktop\intel.ini"
set "EA_NAME=intel.ex5"
set "RESULTS_FILE=C:\Users\Satyam\Desktop\tester_last_results.txt"
set "RUNNING_FLAG=C:\Users\Satyam\Desktop\tester_running.flag"
set "STOP_FLAG=C:\Users\Satyam\Desktop\tester_stop.flag"
set "DELAY_BETWEEN_RUNS=30"
set "PS_SCRIPT=%~dp0t1_tester_loop.ps1"
:: =====================================================================

if not exist "%TERMINAL%" (
    echo ERROR: MT5 terminal not found at %TERMINAL%
    pause
    exit /b 1
)

if not exist "%INI_FILE%" (
    echo ERROR: INI file not found at %INI_FILE%
    pause
    exit /b 1
)

if not exist "%PS_SCRIPT%" (
    echo ERROR: PowerShell script not found at %PS_SCRIPT%
    pause
    exit /b 1
)

if exist "%STOP_FLAG%" del "%STOP_FLAG%"
if exist "%RUNNING_FLAG%" del "%RUNNING_FLAG%"

echo ============================================================
echo   T1 Strategy Tester - Periodic Backtest Loop
echo   INI: %INI_FILE%
echo   EA:  %EA_NAME%
echo   MT5: %TERMINAL%
echo   Delay between runs: %DELAY_BETWEEN_RUNS%s
echo   To stop gracefully, create (empty file): %STOP_FLAG%
echo   Or press Ctrl+C
echo ============================================================
echo.

:: Parse and show INI summary
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$c = Get-Content -LiteralPath \"%INI_FILE%\" -Encoding Unicode;" ^
    "$from = ($c | Where-Object { $_ -match '^FromDate=(.+)' } | ForEach-Object { $matches[1] });" ^
    "$to = ($c | Where-Object { $_ -match '^ToDate=(.+)' } | ForEach-Object { $matches[1] });" ^
    "$sym = ($c | Where-Object { $_ -match '^Symbol=(.+)' } | ForEach-Object { $matches[1] });" ^
    "$per = ($c | Where-Object { $_ -match '^Period=(.+)' } | ForEach-Object { $matches[1] });" ^
    "Write-Host ('  Symbol: {0}  Period: {1}  From: {2}  To: {3}' -f $sym,$per,$from,$to)"

if %errorlevel% neq 0 (
    echo ERROR: Failed to parse INI file. Make sure it exists and is valid.
    pause
    exit /b 1
)

echo.
set "CYCLE=0"

:LOOP
set /a CYCLE+=1

if exist "%STOP_FLAG%" (
    echo Stop flag detected. Exiting.
    del "%STOP_FLAG%" 2>nul
    goto :END
)

echo.
echo ======================== Cycle #%CYCLE% ========================
echo %date% %time%

powershell -NoProfile -ExecutionPolicy Bypass -File "%PS_SCRIPT%" ^
    -TERMINAL "%TERMINAL%" ^
    -INI_FILE "%INI_FILE%" ^
    -EA_NAME "%EA_NAME%" ^
    -RESULTS_FILE "%RESULTS_FILE%" ^
    -RUNNING_FLAG "%RUNNING_FLAG%" ^
    -STOP_FLAG "%STOP_FLAG%" ^
    -CYCLE %CYCLE% ^
    -DELAY %DELAY_BETWEEN_RUNS%

if errorlevel 1 (
    echo.
    echo WARNING: Test cycle ended with an error.
)

if exist "%RESULTS_FILE%" (
    set /p LAST_RESULT=<"%RESULTS_FILE%"
    echo.
    type "%RESULTS_FILE%"
)

echo.
echo -------- Waiting %DELAY_BETWEEN_RUNS%s before next cycle --------
echo (Create "%STOP_FLAG%" to stop gracefully)
for /l %%i in (%DELAY_BETWEEN_RUNS%,-1,1) do (
    if exist "%STOP_FLAG%" goto :END
    ping -n 2 127.0.0.1 >nul 2>&1
)
goto :LOOP

:END
echo.
echo Gracefully stopped after Cycle #%CYCLE%.
if exist "%RUNNING_FLAG%" del "%RUNNING_FLAG%" 2>nul
if exist "%STOP_FLAG%" del "%STOP_FLAG%" 2>nul
echo Results saved in: %RESULTS_FILE%
pause
