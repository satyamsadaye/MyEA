from PyQt6.QtWidgets import (
    QWidget, QScrollArea, QVBoxLayout, QFormLayout, QComboBox,
    QSpinBox, QDoubleSpinBox, QCheckBox, QLineEdit, QGroupBox,
    QPushButton, QHBoxLayout, QFileDialog, QMessageBox, QLabel
)
from PyQt6.QtCore import Qt, pyqtSignal
from typing import Optional
from ..core.settings_model import EASettings
from ..core.ea_config_manager import read_set_file


INPUT_GROUPS = [
    ("Strategy Selection", [
        ("strategy_mode", "Strategy Mode", "combo"),
        ("selected_strategy", "Selected Strategy", "spin", 1, 1000),
        ("allowed_direction", "Allowed Direction", "combo"),
        ("min_votes_to_trade", "Min Votes To Trade", "spin", 1, 1000),
        ("one_trade_per_bar", "One Trade Per Bar", "bool"),
        ("reverse_signals", "Reverse Signals", "bool"),
    ]),
    ("Position Limits", [
        ("max_open_positions", "Max Open Positions", "spin", 1, 100),
        ("magic_number", "Magic Number", "spin", 1, 999999999),
        ("slippage_points", "Slippage Points", "spin", 0, 1000),
    ]),
    ("Lot Sizing", [
        ("lot_mode", "Lot Mode", "combo"),
        ("risk_per_trade_percent", "Risk Per Trade %", "double", 0.01, 100.0, 2),
        ("custom_starting_balance", "Custom Starting Balance", "double", 1.0, 99999999.0, 2),
        ("fixed_lot", "Fixed Lot", "double", 0.01, 1000.0, 2),
        ("max_lot", "Max Lot", "double", 0.01, 10000.0, 2),
    ]),
    ("Stop Loss / Take Profit", [
        ("stop_loss_mode", "Stop Loss Mode", "combo"),
        ("take_profit_mode", "Take Profit Mode", "combo"),
        ("atr_period", "ATR Period", "spin", 1, 100),
        ("sl_atr_multiplier", "SL ATR Multiplier", "double", 0.1, 100.0, 1),
        ("tp_atr_multiplier", "TP ATR Multiplier", "double", 0.1, 100.0, 1),
        ("fixed_sl_points", "Fixed SL Points", "double", 1.0, 99999.0, 1),
        ("fixed_tp_points", "Fixed TP Points", "double", 1.0, 99999.0, 1),
        ("sl_money", "SL Money", "double", 0.01, 999999.0, 2),
        ("tp_money", "TP Money", "double", 0.01, 999999.0, 2),
        ("place_broker_sl_tp", "Place Broker SL/TP", "bool"),
    ]),
    ("Virtual Dollar Exit", [
        ("enable_virtual_dollar_exit", "Enable Virtual Dollar Exit", "bool"),
        ("virtual_exit_lot", "Virtual Exit Lot", "double", 0.01, 1000.0, 2),
        ("virtual_take_profit_money", "Virtual TP Money", "double", 0.01, 999999.0, 2),
        ("virtual_stop_loss_money", "Virtual SL Money", "double", 0.01, 999999.0, 2),
        ("disable_broker_stops_when_virtual", "Disable Broker Stops When Virtual", "bool"),
    ]),
    ("EA Stop Protection", [
        ("enable_protection_stops", "Enable Protection Stops", "bool"),
        ("stop_profit_money", "Stop Profit Money", "double", 0.0, 999999.0, 2),
        ("stop_loss_money", "Stop Loss Money", "double", 0.0, 999999.0, 2),
        ("stop_drawdown_money", "Stop Drawdown Money", "double", 0.0, 999999.0, 2),
        ("stop_profit_percent_of_start", "Stop Profit % of Start", "double", 0.0, 100.0, 2),
        ("stop_loss_percent_of_start", "Stop Loss % of Start", "double", 0.0, 100.0, 2),
        ("stop_drawdown_percent_of_start", "Stop Drawdown % of Start", "double", 0.0, 100.0, 2),
        ("close_positions_when_protection_hit", "Close Positions When Protection Hit", "bool"),
    ]),
    ("Margin Management", [
        ("enable_margin_check", "Enable Margin Check", "bool"),
        ("max_margin_percent_per_trade", "Max Margin % Per Trade", "double", 1.0, 100.0, 1),
    ]),
    ("Global Time Controls", [
        ("enable_global_time_controls", "Enable Global Time Controls", "bool"),
        ("global_pause_hour", "Pause Hour (UTC)", "spin", 0, 23),
        ("global_pause_minute", "Pause Minute (UTC)", "spin", 0, 59),
        ("global_close_hour", "Close Hour (UTC)", "spin", 0, 23),
        ("global_close_minute", "Close Minute (UTC)", "spin", 0, 59),
        ("global_resume_hour", "Resume Hour (UTC)", "spin", 0, 23),
        ("global_resume_minute", "Resume Minute (UTC)", "spin", 0, 59),
    ]),
    ("Propfirm Backtest", [
        ("enable_propfirm_backtest", "Enable Propfirm Backtest Mode", "bool"),
        ("prop_strategy_mode", "Prop Strategy Mode", "combo"),
        ("prop_custom_strategies", "Prop Custom Strategies", "text"),
        ("prop_starting_balance", "Prop Starting Balance", "double", 100.0, 99999999.0, 2),
        ("prop_max_total_dd_percent", "Max Total DD %", "double", 0.1, 100.0, 1),
        ("prop_profit_target_percent", "Profit Target %", "double", 0.1, 1000.0, 1),
        ("prop_enable_daily_dd", "Enable Daily DD", "bool"),
        ("prop_daily_dd_percent", "Daily DD %", "double", 0.1, 100.0, 1),
        ("prop_daily_buffer_percent", "Daily Buffer %", "double", 0.0, 50.0, 1),
        ("prop_daily_reset_hour", "Daily Reset Hour (UTC)", "spin", 0, 23),
        ("prop_daily_reset_minute", "Daily Reset Minute (UTC)", "spin", 0, 59),
        ("prop_pause_hour", "Pause Hour (UTC)", "spin", 0, 23),
        ("prop_pause_minute", "Pause Minute (UTC)", "spin", 0, 59),
        ("prop_close_hour", "Close Hour (UTC)", "spin", 0, 23),
        ("prop_close_minute", "Close Minute (UTC)", "spin", 0, 59),
        ("prop_resume_hour", "Resume Hour (UTC)", "spin", 0, 23),
        ("prop_resume_minute", "Resume Minute (UTC)", "spin", 0, 59),
        ("prop_rolling_start", "Prop Rolling Start Mode", "bool"),
        ("prop_spawn_interval", "Prop Spawn Interval", "combo"),
        ("prop_max_start_days", "Prop Max Start Days", "spin", 0, 365),
        ("prop_html_report_name", "HTML Report Name", "text"),
        ("prop_recency_half_life_days", "Recency Half-Life Days", "double", 0.0, 365.0, 1),
    ]),
    ("Logging", [
        ("enable_csv_log", "Enable CSV Log", "bool"),
        ("log_file_name", "Log File Name", "text"),
        ("print_detailed_log", "Print Detailed Log", "bool"),
    ]),
    ("Receiver EA Connection", [
        ("enable_receiver_connection", "Enable Receiver Connection", "bool"),
        ("receiver_copier_key", "Receiver Copier Key", "text"),
        ("receiver_poll_interval_ms", "Receiver Poll Interval (ms)", "spin", 100, 10000),
    ]),
]


class EASettingsWidget(QWidget):
    settings_changed = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._settings = EASettings()
        self._widgets = {}
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        btn_layout = QHBoxLayout()
        load_btn = QPushButton("Load .set File")
        save_btn = QPushButton("Save .set File")
        reset_btn = QPushButton("Reset to Defaults")
        load_btn.clicked.connect(self._load_set_file)
        save_btn.clicked.connect(self._save_set_file)
        reset_btn.clicked.connect(self._reset_defaults)
        btn_layout.addWidget(load_btn)
        btn_layout.addWidget(save_btn)
        btn_layout.addWidget(reset_btn)
        btn_layout.addStretch()
        layout.addLayout(btn_layout)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll_widget = QWidget()
        scroll_form_layout = QVBoxLayout(scroll_widget)

        for group_name, fields in INPUT_GROUPS:
            group = QGroupBox(group_name)
            form = QFormLayout(group)
            form.setLabelAlignment(Qt.AlignmentFlag.AlignRight)
            for field_def in fields:
                field_name = fields[0] if len(fields) > 0 else field_def[0]
                field_name = field_def[0]
                w = self._create_widget(field_def)
                if w:
                    label = field_def[1]
                    form.addRow(f"{label}:", w)
                    self._widgets[field_name] = w
            scroll_form_layout.addWidget(group)

        scroll_form_layout.addStretch()
        scroll.setWidget(scroll_widget)
        layout.addWidget(scroll)

    def _create_widget(self, field_def):
        field_name = field_def[0]
        wtype = field_def[2]
        if wtype == "combo":
            cb = QComboBox()
            if field_name in EASettings.ENUM_FIELDS:
                cb.addItems(EASettings.ENUM_FIELDS[field_name])
            cb.currentTextChanged.connect(lambda: self.settings_changed.emit())
            return cb
        elif wtype == "spin":
            min_val = field_def[3] if len(field_def) > 3 else 0
            max_val = field_def[4] if len(field_def) > 4 else 999
            sb = QSpinBox()
            sb.setRange(min_val, max_val)
            sb.valueChanged.connect(lambda: self.settings_changed.emit())
            return sb
        elif wtype == "double":
            min_val = field_def[3] if len(field_def) > 3 else 0.0
            max_val = field_def[4] if len(field_def) > 4 else 999999.0
            decimals = field_def[5] if len(field_def) > 5 else 2
            dsb = QDoubleSpinBox()
            dsb.setRange(min_val, max_val)
            dsb.setDecimals(decimals)
            dsb.setSingleStep(10 ** (-decimals))
            dsb.valueChanged.connect(lambda: self.settings_changed.emit())
            return dsb
        elif wtype == "bool":
            cb = QCheckBox()
            cb.toggled.connect(lambda: self.settings_changed.emit())
            return cb
        elif wtype == "text":
            le = QLineEdit()
            le.textChanged.connect(lambda: self.settings_changed.emit())
            return le
        return None

    def settings(self) -> EASettings:
        s = EASettings()
        for field_name, w in self._widgets.items():
            if isinstance(w, QComboBox):
                setattr(s, field_name, w.currentText())
            elif isinstance(w, QSpinBox):
                setattr(s, field_name, w.value())
            elif isinstance(w, QDoubleSpinBox):
                setattr(s, field_name, w.value())
            elif isinstance(w, QCheckBox):
                setattr(s, field_name, w.isChecked())
            elif isinstance(w, QLineEdit):
                setattr(s, field_name, w.text())
        return s

    def set_settings(self, s: EASettings):
        for field_name, w in self._widgets.items():
            val = getattr(s, field_name, None)
            if val is None:
                continue
            if isinstance(w, QComboBox):
                idx = w.findText(str(val))
                if idx >= 0:
                    w.setCurrentIndex(idx)
            elif isinstance(w, QSpinBox):
                w.setValue(int(val))
            elif isinstance(w, QDoubleSpinBox):
                w.setValue(float(val))
            elif isinstance(w, QCheckBox):
                w.setChecked(bool(val))
            elif isinstance(w, QLineEdit):
                w.setText(str(val))

    def _load_set_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "Load .set File", "",
                                              "SET Files (*.set);;All Files (*)")
        if path:
            try:
                s = read_set_file(path)
                self.set_settings(s)
                QMessageBox.information(self, "Loaded", f"Settings loaded from:\n{path}")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to load .set file:\n{e}")

    def _save_set_file(self):
        from ..core.ea_config_manager import easettings_to_set_lines
        path, _ = QFileDialog.getSaveFileName(self, "Save .set File", "",
                                              "SET Files (*.set);;All Files (*)")
        if path:
            try:
                s = self.settings()
                content = easettings_to_set_lines(s)
                with open(path, "w", encoding="utf-8") as f:
                    f.write(content)
                QMessageBox.information(self, "Saved", f"Settings saved to:\n{path}")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to save .set file:\n{e}")

    def _reset_defaults(self):
        self.set_settings(EASettings())
        self.settings_changed.emit()
