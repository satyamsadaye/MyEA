import os
import time
import threading
from typing import Dict, Optional, Callable
from .settings_model import TerminalStatus


class ProgressMonitor:
    def __init__(self, common_paths: Dict[int, str], session_key: str, total_nodes: int):
        self.common_paths = common_paths
        self.session_key = session_key
        self.total_nodes = total_nodes
        self._statuses: Dict[int, TerminalStatus] = {}
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()
        self._on_update: Optional[Callable] = None
        self._processes: Dict[int, int] = {}

    def set_process_pid(self, node: int, pid: int):
        with self._lock:
            self._processes[node] = pid

    def set_on_update(self, callback: Callable):
        self._on_update = callback

    def start(self):
        self._running = True
        self._thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self._thread.start()

    def stop(self):
        self._running = False
        if self._thread:
            self._thread.join(timeout=2.0)

    def get_status(self, node: int) -> Optional[TerminalStatus]:
        with self._lock:
            return self._statuses.get(node)

    def get_all_statuses(self) -> Dict[int, TerminalStatus]:
        with self._lock:
            return dict(self._statuses)

    def all_complete(self) -> bool:
        with self._lock:
            for node, st in self._statuses.items():
                if st.status not in ("Complete", "Error"):
                    return False
            if len(self._statuses) < self.total_nodes:
                return False
            return True

    def any_error(self) -> bool:
        with self._lock:
            return any(s.status == "Error" for s in self._statuses.values())

    def _detect_completion(self, node: int) -> bool:
        path = self.common_paths.get(node)
        if not path:
            return False
        partial_file = os.path.join(path, f"Partial_{self.session_key}_Node{node}.csv")
        log_file = os.path.join(path, f"Partial_{self.session_key}_Node{node}.log")

        if os.path.isfile(partial_file):
            size = os.path.getsize(partial_file)
            if size > 100:
                return True

        if os.path.isfile(log_file):
            with open(log_file, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
                if "DEINIT" in content or "PROP_INIT" in content.split()[-20:]:
                    return True

        return False

    def _estimate_progress(self, node: int) -> float:
        path = self.common_paths.get(node)
        if not path:
            return 0.0
        partial_file = os.path.join(path, f"Partial_{self.session_key}_Node{node}.csv")
        if os.path.isfile(partial_file):
            file_size = os.path.getsize(partial_file)
            if file_size > 10000:
                return min(99.0, file_size / 500000.0 * 100.0)
        log_file = os.path.join(path, f"Partial_{self.session_key}_Node{node}.log")
        if os.path.isfile(log_file):
            try:
                with open(log_file, "r", encoding="utf-8", errors="ignore") as f:
                    content = f.read()
                lines = content.splitlines()
                for line in reversed(lines):
                    if "%" in line:
                        import re
                        m = re.search(r'(\d+)%', line)
                        if m:
                            return float(m.group(1))
            except Exception:
                pass
        return 0.0

    def _monitor_loop(self):
        start_time = time.time()
        while self._running:
            time.sleep(1.0)
            updated = False
            with self._lock:
                for node in range(1, self.total_nodes + 1):
                    if node not in self._statuses:
                        self._statuses[node] = TerminalStatus(
                            node_number=node, path=self.common_paths.get(node, ""),
                            status="Starting"
                        )
                    st = self._statuses[node]
                    try:
                        import psutil
                    except ImportError:
                        psutil = None
                    if psutil and st.pid and psutil.pid_exists(st.pid):
                        try:
                            proc = psutil.Process(st.pid)
                            st.cpu_percent = proc.cpu_percent(interval=0.0)
                            st.memory_mb = proc.memory_info().rss / (1024 * 1024)
                        except (psutil.NoSuchProcess, psutil.AccessDenied):
                            st.cpu_percent = 0.0
                            st.memory_mb = 0.0
                            if st.status == "Running":
                                st.status = "Complete"
                                st.progress = 100.0
                    st.elapsed_seconds = int(time.time() - start_time)
                    if st.status == "Starting":
                        st.status = "Running"
                    if st.status == "Running":
                        prog = self._estimate_progress(node)
                        if prog > st.progress:
                            st.progress = prog
                        if self._detect_completion(node):
                            st.status = "Complete"
                            st.progress = 100.0
                    updated = True
                if not updated:
                    for node in range(1, self.total_nodes + 1):
                        if node not in self._statuses:
                            self._statuses[node] = TerminalStatus(
                                node_number=node, path=self.common_paths.get(node, ""),
                                status="Starting"
                            )
            if self._on_update:
                self._on_update()
