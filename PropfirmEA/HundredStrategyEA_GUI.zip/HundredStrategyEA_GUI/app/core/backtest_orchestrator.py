import os
import subprocess
import time
from datetime import datetime
from typing import List, Dict, Optional, Callable
from .settings_model import EASettings, TerminalConfig, BacktestConfig
from .ea_config_manager import (
    easettings_to_set_lines, get_terminal_set_path, get_common_files_path
)
from .progress_monitor import ProgressMonitor


class BacktestOrchestrator:
    def __init__(self):
        self._processes: Dict[int, subprocess.Popen] = {}
        self._monitor: Optional[ProgressMonitor] = None
        self.session_key: str = ""
        self._running = False

    @property
    def monitor(self) -> Optional[ProgressMonitor]:
        return self._monitor

    def _generate_session_key(self) -> str:
        now = datetime.now()
        return f"bt{now.strftime('%Y%m%d_%H%M%S')}"

    def _get_common_dirs(self, terminals: List[TerminalConfig]) -> Dict[int, str]:
        return {tc.node_number: get_common_files_path(tc.data_folder) for tc in terminals}

    def launch_backtests(self, settings: EASettings, terminals: List[TerminalConfig],
                         backtest_cfg: BacktestConfig,
                         on_update: Optional[Callable] = None) -> bool:
        if self._running:
            return False
        self._running = True
        self.session_key = self._generate_session_key()
        total_nodes = len(terminals)

        for tc in terminals:
            settings.prop_html_report_name = f"Propfirm_100_Strategy_Report_{self.session_key}.html"

        config_strs = {}
        for tc in terminals:
            cfg_lines = easettings_to_set_lines(
                settings, parallel_mode=1,
                node_number=tc.node_number,
                total_nodes=total_nodes,
                session_key=self.session_key
            )
            config_strs[tc.node_number] = cfg_lines

        for tc in terminals:
            set_path = get_terminal_set_path(tc.data_folder)
            os.makedirs(os.path.dirname(set_path), exist_ok=True)
            with open(set_path, "w", encoding="utf-8") as f:
                f.write(config_strs[tc.node_number])

        common_dirs = self._get_common_dirs(terminals)
        self._monitor = ProgressMonitor(common_dirs, self.session_key, total_nodes)
        self._monitor.set_on_update(on_update)
        self._monitor.start()

        for tc in terminals:
            exe_path = tc.path
            if not os.path.isfile(exe_path):
                continue
            try:
                proc = subprocess.Popen(
                    [exe_path],
                    cwd=os.path.dirname(exe_path),
                    creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0,
                )
                self._processes[tc.node_number] = proc
                if self._monitor:
                    self._monitor.set_process_pid(tc.node_number, proc.pid)
            except Exception:
                if self._monitor:
                    st = self._monitor.get_status(tc.node_number)
                    if st:
                        st.status = "Error"
                        st.error = f"Failed to launch: {exe_path}"

        return True

    def stop_all(self):
        self._running = False
        if self._monitor:
            self._monitor.stop()
        for node, proc in self._processes.items():
            try:
                proc.terminate()
                proc.wait(timeout=5)
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass
        self._processes.clear()

    def all_complete(self) -> bool:
        if not self._monitor:
            return False
        return self._monitor.all_complete()

    def any_error(self) -> bool:
        if not self._monitor:
            return False
        return self._monitor.any_error()

    def cleanup(self):
        self.stop_all()

    def reset_settings(self, settings: EASettings, terminals: List[TerminalConfig]):
        for tc in terminals:
            set_path = get_terminal_set_path(tc.data_folder)
            cfg_lines = easettings_to_set_lines(
                settings, parallel_mode=0,
                node_number=1, total_nodes=1, session_key=""
            )
            os.makedirs(os.path.dirname(set_path), exist_ok=True)
            with open(set_path, "w", encoding="utf-8") as f:
                f.write(cfg_lines)
