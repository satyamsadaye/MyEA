import os
import configparser
from typing import Optional
from .settings_model import EASettings


SET_FIELD_MAP = {
    "StrategyMode": ("strategy_mode", None),
    "SelectedStrategy": ("selected_strategy", None),
    "AllowedDirection": ("allowed_direction", None),
    "MinVotesToTrade": ("min_votes_to_trade", None),
    "OneTradePerBar": ("one_trade_per_bar", "bool"),
    "ReverseSignals": ("reverse_signals", "bool"),
    "MaxOpenPositions": ("max_open_positions", None),
    "MagicNumber": ("magic_number", None),
    "SlippagePoints": ("slippage_points", None),
    "LotMode": ("lot_mode", None),
    "RiskPerTradePercent": ("risk_per_trade_percent", None),
    "CustomStartingBalance": ("custom_starting_balance", None),
    "FixedLot": ("fixed_lot", None),
    "MaxLot": ("max_lot", None),
    "StopLossMode": ("stop_loss_mode", None),
    "TakeProfitMode": ("take_profit_mode", None),
    "AtrPeriod": ("atr_period", None),
    "SlAtrMultiplier": ("sl_atr_multiplier", None),
    "TpAtrMultiplier": ("tp_atr_multiplier", None),
    "FixedSlPoints": ("fixed_sl_points", None),
    "FixedTpPoints": ("fixed_tp_points", None),
    "SlMoney": ("sl_money", None),
    "TpMoney": ("tp_money", None),
    "PlaceBrokerStopLossTakeProfit": ("place_broker_sl_tp", "bool"),
    "EnableVirtualDollarExit": ("enable_virtual_dollar_exit", "bool"),
    "VirtualExitLot": ("virtual_exit_lot", None),
    "VirtualTakeProfitMoney": ("virtual_take_profit_money", None),
    "VirtualStopLossMoney": ("virtual_stop_loss_money", None),
    "DisableBrokerStopsWhenVirtualExitOn": ("disable_broker_stops_when_virtual", "bool"),
    "EnableProtectionStops": ("enable_protection_stops", "bool"),
    "StopProfitMoney": ("stop_profit_money", None),
    "StopLossMoney": ("stop_loss_money", None),
    "StopDrawdownMoney": ("stop_drawdown_money", None),
    "StopProfitPercentOfStart": ("stop_profit_percent_of_start", None),
    "StopLossPercentOfStart": ("stop_loss_percent_of_start", None),
    "StopDrawdownPercentOfStart": ("stop_drawdown_percent_of_start", None),
    "ClosePositionsWhenProtectionHit": ("close_positions_when_protection_hit", "bool"),
    "EnableMarginCheck": ("enable_margin_check", "bool"),
    "MaxMarginPercentPerTrade": ("max_margin_percent_per_trade", None),
    "EnableGlobalTimeControls": ("enable_global_time_controls", "bool"),
    "GlobalPauseSignalsHourUTC": ("global_pause_hour", None),
    "GlobalPauseSignalsMinuteUTC": ("global_pause_minute", None),
    "GlobalCloseAllHourUTC": ("global_close_hour", None),
    "GlobalCloseAllMinuteUTC": ("global_close_minute", None),
    "GlobalResumeSignalsHourUTC": ("global_resume_hour", None),
    "GlobalResumeSignalsMinuteUTC": ("global_resume_minute", None),
    "EnablePropfirmBacktestMode": ("enable_propfirm_backtest", "bool"),
    "PropStrategyMode": ("prop_strategy_mode", None),
    "PropCustomStrategies": ("prop_custom_strategies", None),
    "PropStartingBalance": ("prop_starting_balance", None),
    "PropMaxTotalDrawdownPercent": ("prop_max_total_dd_percent", None),
    "PropProfitTargetPercent": ("prop_profit_target_percent", None),
    "PropEnableDailyDrawdown": ("prop_enable_daily_dd", "bool"),
    "PropDailyDrawdownPercent": ("prop_daily_dd_percent", None),
    "PropDailyProtectionBufferPercent": ("prop_daily_buffer_percent", None),
    "PropDailyResetHourUTC": ("prop_daily_reset_hour", None),
    "PropDailyResetMinuteUTC": ("prop_daily_reset_minute", None),
    "PropPauseSignalsHourUTC": ("prop_pause_hour", None),
    "PropPauseSignalsMinuteUTC": ("prop_pause_minute", None),
    "PropCloseAllHourUTC": ("prop_close_hour", None),
    "PropCloseAllMinuteUTC": ("prop_close_minute", None),
    "PropResumeSignalsHourUTC": ("prop_resume_hour", None),
    "PropResumeSignalsMinuteUTC": ("prop_resume_minute", None),
    "PropRollingStartMode": ("prop_rolling_start", "bool"),
    "PropSpawnInterval": ("prop_spawn_interval", None),
    "PropMaxStartDays": ("prop_max_start_days", None),
    "PropHtmlReportFileName": ("prop_html_report_name", None),
    "PropRecencyHalfLifeDays": ("prop_recency_half_life_days", None),
    "ParallelMode": (None, None),
    "ParallelNodeNumber": (None, None),
    "ParallelTotalNodes": (None, None),
    "ParallelSessionKey": (None, None),
    "EnableCsvLog": ("enable_csv_log", "bool"),
    "LogFileName": ("log_file_name", None),
    "PrintDetailedLog": ("print_detailed_log", "bool"),
    "EnableReceiverConnection": ("enable_receiver_connection", "bool"),
    "ReceiverCopierKey": ("receiver_copier_key", None),
    "ReceiverPollIntervalMs": ("receiver_poll_interval_ms", None),
}

ENUM_REVERSE_MAP = {}
for enum_name, opts in EASettings.ENUM_FIELDS.items():
    for opt in opts:
        ENUM_REVERSE_MAP[opt] = enum_name


STRING_FIELDS = {
    "strategy_mode", "allowed_direction", "lot_mode", "stop_loss_mode",
    "take_profit_mode", "prop_strategy_mode", "prop_custom_strategies",
    "prop_spawn_interval", "log_file_name", "prop_html_report_name",
    "receiver_copier_key",
}

INT_FIELDS = {
    "selected_strategy", "min_votes_to_trade", "max_open_positions", "magic_number",
    "slippage_points", "atr_period", "global_pause_hour", "global_pause_minute",
    "global_close_hour", "global_close_minute", "global_resume_hour", "global_resume_minute",
    "prop_daily_reset_hour", "prop_daily_reset_minute", "prop_pause_hour", "prop_pause_minute",
    "prop_close_hour", "prop_close_minute", "prop_resume_hour", "prop_resume_minute",
    "prop_max_start_days", "receiver_poll_interval_ms",
}


def parse_set_value(value_str: str, field_name: str) -> object:
    stripped = value_str.strip()
    if field_name in EASettings.BOOL_FIELDS:
        return stripped.lower() in ("true", "1", "yes")
    if field_name in INT_FIELDS:
        return int(stripped)
    if field_name in STRING_FIELDS:
        return stripped
    try:
        if "." in stripped or "e" in stripped.lower():
            return float(stripped)
        return int(stripped)
    except ValueError:
        return stripped


def format_set_value(value: object, field_name: str) -> str:
    if field_name in EASettings.BOOL_FIELDS:
        return "true" if value else "false"
    if isinstance(value, float):
        return f"{value:.2f}"
    return str(value)


def easettings_to_set_lines(settings: EASettings, parallel_mode: int = 0,
                            node_number: int = 1, total_nodes: int = 1,
                            session_key: str = "") -> str:
    lines = ["//--- input parameters"]
    for set_name, (model_field, conv) in SET_FIELD_MAP.items():
        if model_field is not None:
            value = getattr(settings, model_field)
            lines.append(f"{set_name}={format_set_value(value, model_field)}")
        else:
            if set_name == "ParallelMode":
                lines.append(f"{set_name}={parallel_mode}")
            elif set_name == "ParallelNodeNumber":
                lines.append(f"{set_name}={node_number}")
            elif set_name == "ParallelTotalNodes":
                lines.append(f"{set_name}={total_nodes}")
            elif set_name == "ParallelSessionKey":
                lines.append(f"{set_name}={session_key}")
    return "\n".join(lines) + "\n"


def set_lines_to_easettings(lines: str) -> EASettings:
    settings = EASettings()
    for line in lines.splitlines():
        line = line.strip()
        if not line or line.startswith("//") or line.startswith("#"):
            continue
        if "=" not in line:
            continue
        set_name, value_str = line.split("=", 1)
        set_name = set_name.strip()
        value_str = value_str.strip()
        if set_name not in SET_FIELD_MAP:
            continue
        model_field, conv = SET_FIELD_MAP[set_name]
        if model_field is None:
            continue
        parsed = parse_set_value(value_str, model_field)
        setattr(settings, model_field, parsed)
    return settings


def write_set_file(filepath: str, settings: EASettings, parallel_mode: int = 0,
                   node_number: int = 1, total_nodes: int = 1,
                   session_key: str = "") -> None:
    content = easettings_to_set_lines(settings, parallel_mode, node_number, total_nodes, session_key)
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(content)


def read_set_file(filepath: str) -> EASettings:
    with open(filepath, "r", encoding="utf-8") as f:
        content = f.read()
    return set_lines_to_easettings(content)


def get_terminal_set_path(terminal_data_folder: str, ea_name: str = "HundredStrategyEA") -> str:
    tester_dir = os.path.join(terminal_data_folder, "MQL5", "Profiles", "Tester")
    return os.path.join(tester_dir, f"{ea_name}.set")


def get_common_files_path(terminal_data_folder: str) -> str:
    return os.path.join(terminal_data_folder, "Files", "Common")
