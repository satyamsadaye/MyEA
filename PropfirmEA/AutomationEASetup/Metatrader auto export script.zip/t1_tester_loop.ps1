param(
    [string]$TERMINAL = "C:\Program Files\MetaTrader 52\terminal64.exe",
    [string]$INI_FILE = "",
    [string]$EA_NAME = "intel.ex5",
    [string]$RESULTS_FILE = "",
    [string]$RUNNING_FLAG = "",
    [string]$STOP_FLAG = "",
    [int]$CYCLE = 1,
    [int]$DELAY = 30
)

$REPORT_DIR = [System.IO.Path]::GetDirectoryName($INI_FILE)

$tmpIni = [System.IO.Path]::GetTempFileName() + '.ini'
$c = Get-Content -LiteralPath $INI_FILE -Encoding Unicode

$c = $c -replace '^Expert=.*', "Expert=$EA_NAME"
$inTester = $false; $found = $false; $result = @()
foreach ($line in $c) {
    if ($line -match '^\[Tester\]$') { $inTester = $true; $result += $line; continue }
    if ($inTester -and $line -match '^\[.+\]') {
        if (-not $found) { $result += "ShutdownTerminal=1"; $found = $true }
        $inTester = $false
    }
    if ($inTester -and $line -match '^ShutdownTerminal') { $found = $true }
    $result += $line
}
if (-not $found) { $result += "ShutdownTerminal=1" }
$result | Set-Content -LiteralPath $tmpIni -Encoding Unicode

$fromStr = ($c | Where-Object { $_ -match '^FromDate=(.+)' } | ForEach-Object { $matches[1] })
$toStr = ($c | Where-Object { $_ -match '^ToDate=(.+)' } | ForEach-Object { $matches[1] })
$sym = ($c | Where-Object { $_ -match '^Symbol=(.+)' } | ForEach-Object { $matches[1] })
$per = ($c | Where-Object { $_ -match '^Period=(.+)' } | ForEach-Object { $matches[1] })

$fromDate = [DateTime]::ParseExact($fromStr, 'yyyy.MM.dd', $null)
$toDate = [DateTime]::ParseExact($toStr, 'yyyy.MM.dd', $null)
$totalDays = [math]::Max(1, ($toDate - $fromDate).TotalDays)

Set-Content -LiteralPath $RUNNING_FLAG -Value ("Running cycle $CYCLE since " + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')) -Encoding Ascii

$daysStr = if ($totalDays -ge 1) { "$($totalDays.ToString('F0')) days" } else { "$($([math]::Round($totalDays*24))) hours" }
Write-Host ("  Config: $sym | $per | $fromStr -> $toStr ($daysStr)") -ForegroundColor Cyan
Write-Host ""

Write-Host "Starting MT5 tester (minimized)..." -ForegroundColor Green
$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $TERMINAL
$psi.Arguments = "/config:`"$tmpIni`""
$psi.UseShellExecute = $true
$psi.WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Minimized
$proc = [System.Diagnostics.Process]::Start($psi)
$pid = $proc.Id
Write-Host ("  PID: $pid") -ForegroundColor Gray
Write-Host ""

$startTime = Get-Date
$spin = @('|', '/', '-', '\')
$si = 0

# Wait for process to exit (ShutdownTerminal=1 closes terminal when test finishes)
while (-not $proc.HasExited) {
    $elapsed = (Get-Date) - $startTime
    $elapsedStr = '{0:D2}:{1:D2}:{2:D2}' -f $elapsed.Hours, $elapsed.Minutes, $elapsed.Seconds

    Write-Host ("`r  Elapsed: $elapsedStr $($spin[$si % 4])") -NoNewline -ForegroundColor Yellow
    $si++

    # Kill if terminal process went zombie
    $alive = Get-Process -Id $pid -ErrorAction SilentlyContinue
    if (-not $alive) { break }

    if (Test-Path -LiteralPath $STOP_FLAG) {
        Write-Host ""; Write-Host "Stop flag detected. Killing process..." -ForegroundColor Red
        $proc.Kill(); $proc.WaitForExit(10000)
        if (-not $proc.HasExited) { Stop-Process -Id $pid -Force -ErrorAction SilentlyContinue }
        break
    }
    Start-Sleep -Milliseconds 1000
}

$proc.WaitForExit(5000)
$endTime = Get-Date
$totalElapsed = $endTime - $startTime
Write-Host ""
Write-Host ("Finished. Duration: {0:D2}:{1:D2}:{2:D2}" -f $totalElapsed.Hours,$totalElapsed.Minutes,$totalElapsed.Seconds) -ForegroundColor Green
Write-Host ("Exit code: $($proc.ExitCode)") -ForegroundColor Gray

if (Test-Path $RUNNING_FLAG) { Remove-Item $RUNNING_FLAG -Force -ErrorAction SilentlyContinue }

$reportFiles = @(Get-ChildItem -LiteralPath $REPORT_DIR -Filter '*Propfirm*Report*.html' -ErrorAction SilentlyContinue)
$reportFiles += @(Get-ChildItem -LiteralPath $REPORT_DIR -Filter '*Intelligent*Live*Trader*Report*.html' -ErrorAction SilentlyContinue)
$commonDir = "$env:APPDATA\MetaQuotes\Tester\*\Agent-*\files\Common"
$reportFiles += Get-ChildItem -Path $commonDir -Filter '*Propfirm*Report*.html' -ErrorAction SilentlyContinue
$reportFiles += Get-ChildItem -Path $commonDir -Filter '*Intelligent*Live*Trader*Report*.html' -ErrorAction SilentlyContinue
$reportFiles = $reportFiles | Sort-Object LastWriteTime -Descending | Select-Object -Unique
if ($reportFiles.Count -gt 0) {
    $rpt = $reportFiles[0]
    Write-Host ("Report: $($rpt.FullName)") -ForegroundColor Cyan
    try {
        $content = Get-Content -LiteralPath $rpt.FullName -Encoding UTF8 -Raw
        $pm = [regex]::Match($content, '(?i)(?:Pass|Passed|Pass Rate)[^0-9]*([0-9]+(?:\.[0-9]+)?)\s*%')
        if ($pm.Success) {
            $stratCount = [regex]::Matches($content, '(?i)STRAT_').Count
            $resultLine = "{0} | Pass Rate: {1}% | Strats: {2} | Duration: {3}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$pm.Groups[1].Value,$stratCount,$totalElapsed.ToString('hh\:mm\:ss')
        } else {
            $resultLine = "{0} | Report: {1}KB | Duration: {2}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),[math]::Round($rpt.Length/1KB),$totalElapsed.ToString('hh\:mm\:ss')
        }
    } catch { $resultLine = "{0} | Completed at {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$totalElapsed.ToString('hh\:mm\:ss') }
} else {
    $resultLine = "{0} | Completed (no report) | Duration: {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$totalElapsed.ToString('hh\:mm\:ss')
}
$resultLine | Out-File -LiteralPath $RESULTS_FILE -Encoding Ascii
Write-Host $resultLine -ForegroundColor Green

Remove-Item $tmpIni -Force -ErrorAction SilentlyContinue
