import subprocess, json, shutil, sys, time, os, csv
from datetime import datetime, timedelta, timezone

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
NODE_SCRIPT = os.path.join(BASE_DIR, 'duka_dl.cjs')
JSON_DIR = os.path.join(BASE_DIR, 'json')
MT5_DIR = os.path.join(BASE_DIR, 'mt5')

os.makedirs(JSON_DIR, exist_ok=True)
os.makedirs(MT5_DIR, exist_ok=True)

def run_node(cmd, *args):
    result = subprocess.run(
        ['node', NODE_SCRIPT, cmd, *args],
        capture_output=True, text=True, timeout=600
    )
    if result.returncode != 0:
        return None, result.stderr.strip()
    return result.stdout.strip(), None

def progress_bar(current, total, elapsed, label=''):
    if total == 0: return
    pct = current / total
    bar_len = 30
    filled = int(bar_len * pct)
    bar = '#' * filled + '-' * (bar_len - filled)
    eta = elapsed / current * (total - current) if current > 0 else 0
    sys.stdout.write(f'\r  {label} {bar} {pct*100:5.1f}%  [{current}/{total}]  ETA: {eta:.0f}s')
    sys.stdout.flush()

def json_to_mt5_m1_csv(json_file, csv_file, offset_h=2):
    with open(json_file, 'r') as f:
        candles = json.load(f)
    total = len(candles)
    print(f'\nConverting {total:,} M1 candles to MT5 CSV (server time UTC+{offset_h})...')
    with open(csv_file, 'w', newline='') as f:
        writer = csv.writer(f)
        chunk_sz = 50000
        for i in range(0, total, chunk_sz):
            chunk = candles[i:i + chunk_sz]
            rows = []
            for c in chunk:
                ts = datetime.fromtimestamp(c['timestamp'] / 1000 + offset_h * 3600, tz=timezone.utc)
                rows.append([
                    ts.strftime('%Y.%m.%d %H:%M'),
                    f"{c['open']:g}",
                    f"{c['high']:g}",
                    f"{c['low']:g}",
                    f"{c['close']:g}",
                    f"{c.get('volume', 0)}"
                ])
            writer.writerows(rows)
            pct = min((i + chunk_sz) / total, 1.0)
            bar = '#' * int(30 * pct) + '-' * (30 - int(30 * pct))
            sys.stdout.write(f'\r  Converting {bar} {pct*100:5.1f}%  [{min(i+chunk_sz,total):,}/{total:,}]')
            sys.stdout.flush()
    print()
    return os.path.getsize(csv_file) / (1024 * 1024)

def json_to_mt5_csv(json_file, csv_file, offset_h=2):
    with open(json_file, 'r') as f:
        ticks = json.load(f)
    total = len(ticks)
    print(f'\nConverting {total:,} ticks to MT5 CSV (server time UTC+{offset_h})...')
    with open(csv_file, 'w', newline='') as f:
        writer = csv.writer(f)
        chunk_sz = 50000
        for i in range(0, total, chunk_sz):
            chunk = ticks[i:i + chunk_sz]
            rows = []
            for t in chunk:
                ts = datetime.fromtimestamp(t['timestamp'] / 1000 + offset_h * 3600, tz=timezone.utc)
                rows.append([
                    ts.strftime('%Y.%m.%d %H:%M:%S.') + f"{t['timestamp'] % 1000:03d}",
                    f"{t['askPrice']:g}",  # Dukascopy returns bid > ask; swap so Bid < Ask
                    f"{t['bidPrice']:g}"
                ])
            writer.writerows(rows)
            pct = min((i + chunk_sz) / total, 1.0)
            bar = '#' * int(30 * pct) + '-' * (30 - int(30 * pct))
            sys.stdout.write(f'\r  Converting {bar} {pct*100:5.1f}%  [{min(i+chunk_sz,total):,}/{total:,}]')
            sys.stdout.flush()
    print()
    return os.path.getsize(csv_file) / (1024 * 1024)

# Step 0: Always UTC
print('All times in UTC (UTC+0)\n')

# Step 1: Latest prices
print('Fetching latest prices...')
out, err = run_node('latest')
if err:
    print('Error:', err)
    exit(1)
prices = json.loads(out)
print('\n========== LATEST PRICES (UTC) ==========')
for p in prices:
    spread = abs(p['ask'] - p['bid'])
    print(f"  {p['symbol']}")
    print(f"    Bid: {p['bid']}  |  Ask: {p['ask']}  |  Spread: {spread:g}")
    print(f"    Bid Vol: {p['bidVol']}  |  Ask Vol: {p['askVol']}")
    print(f"    UTC: {p['utc']}")
    print(f"    IST: {p['ist']}")
    print()
print('=========================================\n')

# Step 2: Symbol
print('Select symbol:')
print('  1. XAU/USD')
print('  2. BTC/USD')
choice = input('Enter 1 or 2: ').strip()
sym_map = {'1': 'xauusd', '2': 'btcusd'}
label_map = {'1': 'XAU/USD', '2': 'BTC/USD'}
if choice not in sym_map:
    print('Invalid choice')
    exit(1)
symbol = sym_map[choice]
label = label_map[choice]

# Step 3: Data type (tick vs M1)
print()
print('Select data type:')
print('  1. Tick data (raw every tick)')
print('  2. 1-minute OHLC (for MT5 backtests)')
dt_choice = input('Enter 1 or 2: ').strip()
dt_map = {'1': 'tick', '2': 'm1'}
label_dt = {'1': 'ticks', '2': 'm1'}
if dt_choice not in dt_map:
    print('Invalid choice')
    exit(1)
data_type = dt_map[dt_choice]
data_label = label_dt[dt_choice]

# Step 4: Date
today_dt = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
while True:
    date_str = input('Enter from date (dd/mm/yyyy): ').strip()
    try:
        dt = datetime.strptime(date_str, '%d/%m/%Y')
        if dt.replace(tzinfo=timezone.utc) > today_dt:
            print('Date cannot be in the future')
            continue
        break
    except ValueError:
        print('Invalid format. Use dd/mm/yyyy')

# Step 5: Download day by day
start = dt.replace(tzinfo=timezone.utc)
total_days = (today_dt - start).days + 1
dl_ts = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')
out_file = os.path.join(JSON_DIR, f'{symbol}_{data_label}_{start.strftime("%Y%m%d")}_to_now_{dl_ts}.json')

if total_days <= 0:
    print('No days to download')
    exit(1)

utc_now = datetime.now(timezone.utc)
print(f'\nDownloading {label} {data_label} from {dt.strftime("%d/%m/%Y")} to today ({total_days} days)')
print(f'  Dukascopy uses UTC time — current UTC: {utc_now.strftime("%H:%M:%S")}\n')

start_time = time.time()
total_ticks = 0
for i in range(total_days):
    day = start + timedelta(days=i)
    day_from = day.strftime('%Y-%m-%d')
    day_to = day.strftime('%Y-%m-%d')
    day_label = day.strftime('%d/%m/%Y')

    out, err = run_node('day', symbol, day_from, day_to, out_file, data_type)
    if err or not out or not out.startswith('DONE|'):
        print(f'\n  Failed on {day_label}: {err or out}')
        continue

    count = int(out.split('|')[1])
    total_ticks += count
    elapsed = time.time() - start_time
    progress_bar(i + 1, total_days, elapsed, f'{day_label}')

print()
size_mb = os.path.getsize(out_file) / (1024 * 1024) if os.path.exists(out_file) else 0
total_time = time.time() - start_time
print(f'\nDone! {total_ticks:,} {data_label} downloaded in {total_time:.0f}s')
print(f'  JSON: {out_file}')
print(f'  Size: {size_mb:.1f} MB')

# Step 6: Auto-convert to MT5 CSV
print()
offset_str = input('Timezone offset hours from UTC (default 0): ').strip()
offset_h = int(offset_str) if offset_str.lstrip('-').isdigit() else 0
csv_basename = os.path.basename(out_file).replace('.json', '.csv')
csv_file = os.path.join(MT5_DIR, csv_basename)

if data_type == 'm1':
    csv_size = json_to_mt5_m1_csv(out_file, csv_file, offset_h)
    print(f'\nMT5 M1 CSV saved: {csv_file}')
    print(f'  Size: {csv_size:.1f} MB')
    print(f'\nImport into MetaTrader 5 as 1-minute data:')
    print(f'  1. MT5 -> Tools -> History Center (F2) -> Select {symbol.upper()}')
    print(f'  2. Click Import -> Select the CSV file')
    print(f'  3. Data type: "1 minute"')
    print(f'  4. Delimiter: Comma')
    print(f'  5. Column mapping:')
    print(f'     - Column 1 -> Date (format: YYYY.MM.DD HH:MM)')
    print(f'     - Column 2 -> Open')
    print(f'     - Column 3 -> High')
    print(f'     - Column 4 -> Low')
    print(f'     - Column 5 -> Close')
    print(f'     - Column 6 -> Tick Volume')
    print(f'  6. Set time offset = 0')
    print(f'  7. Click Import, then run backtest in "Every tick" mode')
else:
    csv_size = json_to_mt5_csv(out_file, csv_file, offset_h)
    print(f'\nMT5 Tick CSV saved: {csv_file}')
    print(f'  Size: {csv_size:.1f} MB')
    print(f'\nImport into MetaTrader 5 as tick data:')
    print(f'  1. MT5 -> Tools -> History Center (F2) -> Select the custom symbol')
    print(f'  2. Click Import -> Select the CSV file')
    print(f'  3. Data type: "Ticks"')
    print(f'  4. Delimiter: Comma')
    print(f'  5. Column mapping:')
    print(f'     - Column 1 -> Date (format: YYYY.MM.DD HH:MM:SS.FFF)')
    print(f'     - Column 2 -> Bid')
    print(f'     - Column 3 -> Ask')
    print(f'  6. Set time offset = 0')
    print(f'  7. Click Import')
