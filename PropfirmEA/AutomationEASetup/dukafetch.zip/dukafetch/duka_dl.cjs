const { getRealTimeRates } = require('dukascopy-node');
const fs = require('fs');

const [cmd, instrument, fromStr, toStr, outFile, timeframe] = process.argv.slice(2);

if (cmd === 'latest') {
  (async () => {
    const [xau, btc] = await Promise.all([
      getRealTimeRates({ instrument: 'xauusd', timeframe: 'tick', format: 'json', last: 1 }),
      getRealTimeRates({ instrument: 'btcusd', timeframe: 'tick', format: 'json', last: 1 })
    ]);
    const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    const fmtDate = (y, mo, d, h, mi, s) => {
      const ampm = h >= 12 ? 'PM' : 'AM';
      const h12 = h % 12 || 12;
      const pad = n => String(n).padStart(2,'0');
      return `${d} ${months[mo]} ${y} ${pad(h12)}:${pad(mi)}:${pad(s)} ${ampm}`;
    };
    const fmtUTC = t => {
      const d = new Date(t);
      return fmtDate(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate(), d.getUTCHours(), d.getUTCMinutes(), d.getUTCSeconds());
    };
    const fmtIST = t => {
      const d = new Date(t + 5.5*3600000);
      return fmtDate(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate(), d.getUTCHours(), d.getUTCMinutes(), d.getUTCSeconds());
    };
    const enrich = (d, sym) => ({
      symbol: sym, bid: d.bidPrice, ask: d.askPrice,
      bidVol: d.bidVolume, askVol: d.askVolume,
      utc: fmtUTC(d.timestamp), ist: fmtIST(d.timestamp)
    });
    console.log(JSON.stringify([enrich(xau[0], 'XAU/USD'), enrich(btc[0], 'BTC/USD')]));
  })();
}

if (cmd === 'day') {
  (async () => {
    try {
      const from = fromStr + 'T00:00:00Z';
      const to = toStr + 'T23:59:59Z';
      const tf = timeframe || 'tick';
      const data = await getRealTimeRates({
        instrument, timeframe: tf, format: 'json',
        dates: { from, to }
      });
      const existing = fs.existsSync(outFile) ? JSON.parse(fs.readFileSync(outFile, 'utf8')) : [];
      const all = existing.concat(data);
      fs.writeFileSync(outFile, JSON.stringify(all));
      console.log(`DONE|${data.length}`);
    } catch (e) {
      console.error('FAIL|' + e.message);
      process.exit(1);
    }
  })();
}
