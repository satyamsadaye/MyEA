@echo off
title Clear History

set "folder1=C:\Users\Satyam.RAJ.001\AppData\Roaming\MetaQuotes\Terminal\D0E8209F77C8CF37AD8BF550E51FF075\bases\Exness-MT5Trial17\history\BTCUSDm"
set "folder2=C:\Users\Satyam.RAJ.001\AppData\Roaming\MetaQuotes\Terminal\52567D768769B2A12AC3254656D828F6\bases\Exness-MT5Trial17\history\BTCUSDm"
set "folder3=C:\Users\Satyam.RAJ.001\AppData\Roaming\MetaQuotes\Terminal\D0E8209F77C8CF37AD8BF550E51FF075\bases\Exness-MT5Trial17\history\XAUUSDm"
set "folder4=C:\Users\Satyam.RAJ.001\AppData\Roaming\MetaQuotes\Terminal\52567D768769B2A12AC3254656D828F6\bases\Exness-MT5Trial17\history\XAUUSDm"

echo Clearing history...
echo.

for %%f in ("%folder1%" "%folder2%" "%folder3%" "%folder4%") do (
    if exist "%%~f" (
        rem Delete all files
        del /f /s /q "%%~f\*" >nul 2>&1

        rem Delete all subfolders
        for /d %%d in ("%%~f\*") do rd /s /q "%%d"

        echo [OK] Cleared: %%~f
    ) else (
        echo [SKIP] Not found: %%~f
    )
)

echo.
echo Done.
timeout /t 3 /nobreak >nul