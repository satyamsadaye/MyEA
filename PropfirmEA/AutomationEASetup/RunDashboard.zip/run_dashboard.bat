@echo off
cd /d "%~dp0"
python dashboard.py
echo.
echo Press any key to exit...
pause >nul
