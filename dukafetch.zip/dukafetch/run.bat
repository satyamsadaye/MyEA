@echo off
cd /d "%~dp0"
python duka_fetch.py
pause
