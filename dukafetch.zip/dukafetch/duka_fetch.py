import subprocess, json, shutil, sys, time, os, csv
from datetime import datetime, timedelta, timezone

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
NODE_SCRIPT = os.path.join(BASE_DIR, 'duka_dl.cjs')
JSON_DIR = os.path.join(BASE_DIR, 'json')
MT5_DIR = os.path.join(BASE_DIR, 'mt5')

os.makedirs(JSON_DIR, exist_ok=True)
os.makedirs(MT5_DIR, exist_ok=True)

def run_node(cmd, *args):
    result = subprocess.run(
        ['node', NODE_SCRIPT, cmd, *args],
        capture_output=True, text=True, timeout=600
    )
    if result.returncode != 0:
        return None, result.stderr.strip()
    return result.stdout.strip(), None

def progress_bar(current, total, elapsed, label=''):
    if total == 0: return
    pct = current / total
    bar_len = 30
    filled = int(bar_len * pct)
    bar = '#' * filled + '-' * (bar_len - filled)
    eta = elapsed / current * (total - current) if current > 0 else 0
    sys.stdout.write(f'\r  {label} {bar} {pct*100:5.1f}%  [{current}/{total}]  ETA: {eta:.0f}s')
    sys.stdout.flush()

def json_to_mt5_csv(json_file, csv_file, offset_h=2):
    with open(json_file, 'r') as f:
        ticks = json.load(f)
    total = len(ticks)
    print(f'\nConverting {total:,} ticks to MT5 CSV (server time UTC+{offset_h})...')
    with open(csv_file, 'w', newline='') as f:
        writer = csv.writer(f)
        chunk_sz = 50000
        for i in range(0, total, chunk_sz):
            chunk = ticks[i:i + chunk_sz]
            rows = []
            for t in chunk:
                ts = datetime.fromtimestamp(t['timestamp'] / 1000 + offset_h * 3600, tz=timezone.utc)
                rows.append([
                    ts.strftime('%Y.%m.%d %H:%M:%S.') + f"{t['timestamp'] % 1000:03d}",
                    f"{t['bidPrice']:g}",
                    f"{t['askPrice']:g}"
                ])
            writer.writerows(rows)
            pct = min((i + chunk_sz) / total, 1.0)
            bar = '#' * int(30 * pct) + '-' * (30 - int(30 * pct))
            sys.stdout.write(f'\r  Converting {bar} {pct*100:5.1f}%  [{min(i+chunk_sz,total):,}/{total:,}]')
            sys.stdout.flush()
    print()
    return os.path.getsize(csv_file) / (1024 * 1024)

# Step 0: Always UTC
print('All times in UTC (UTC+0)\n')

# Step 1: Latest prices
print('Fetching latest prices...')
out, err = run_node('latest')
if err:
    print('Error:', err)
    exit(1)
prices = json.loads(out)
print('\n========== LATEST PRICES (UTC) ==========')
for p in prices:
    spread = abs(p['ask'] - p['bid'])
    print(f"  {p['symbol']}")
    print(f"    Bid: {p['bid']}  |  Ask: {p['ask']}  |  Spread: {spread:g}")
    print(f"    Bid Vol: {p['bidVol']}  |  Ask Vol: {p['askVol']}")
    print(f"    UTC: {p['utc']}")
    print(f"    IST: {p['ist']}")
    print()
print('=========================================\n')

# Step 2: Symbol
print('Select symbol:')
print('  1. XAU/USD')
print('  2. BTC/USD')
choice = input('Enter 1 or 2: ').strip()
sym_map = {'1': 'xauusd', '2': 'btcusd'}
label_map = {'1': 'XAU/USD', '2': 'BTC/USD'}
if choice not in sym_map:
    print('Invalid choice')
    exit(1)
symbol = sym_map[choice]
label = label_map[choice]

# Step 3: Date
today_dt = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
while True:
    date_str = input('Enter from date (dd/mm/yyyy): ').strip()
    try:
        dt = datetime.strptime(date_str, '%d/%m/%Y')
        if dt.replace(tzinfo=timezone.utc) > today_dt:
            print('Date cannot be in the future')
            continue
        break
    except ValueError:
        print('Invalid format. Use dd/mm/yyyy')

# Step 4: Download day by day
start = dt.replace(tzinfo=timezone.utc)
total_days = (today_dt - start).days + 1
dl_ts = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')
out_file = os.path.join(JSON_DIR, f'{symbol}_ticks_{start.strftime("%Y%m%d")}_to_now_{dl_ts}.json')

if total_days <= 0:
    print('No days to download')
    exit(1)

utc_now = datetime.now(timezone.utc)
print(f'\nDownloading {label} from {dt.strftime("%d/%m/%Y")} to today ({total_days} days)')
print(f'  Dukascopy uses UTC time — current UTC: {utc_now.strftime("%H:%M:%S")}\n')

start_time = time.time()
total_ticks = 0
for i in range(total_days):
    day = start + timedelta(days=i)
    day_from = day.strftime('%Y-%m-%d')
    day_to = day.strftime('%Y-%m-%d')
    day_label = day.strftime('%d/%m/%Y')

    out, err = run_node('day', symbol, day_from, day_to, out_file)
    if err or not out or not out.startswith('DONE|'):
        print(f'\n  Failed on {day_label}: {err or out}')
        continue

    count = int(out.split('|')[1])
    total_ticks += count
    elapsed = time.time() - start_time
    progress_bar(i + 1, total_days, elapsed, f'{day_label}')

print()
size_mb = os.path.getsize(out_file) / (1024 * 1024) if os.path.exists(out_file) else 0
total_time = time.time() - start_time
print(f'\nDone! {total_ticks:,} ticks downloaded in {total_time:.0f}s')
print(f'  JSON: {out_file}')
print(f'  Size: {size_mb:.1f} MB')

# Step 5: Auto-convert to MT5 CSV
print()
offset_str = input('Timezone offset hours from UTC (default 0): ').strip()
offset_h = int(offset_str) if offset_str.lstrip('-').isdigit() else 0
csv_basename = os.path.basename(out_file).replace('.json', '.csv')
csv_file = os.path.join(MT5_DIR, csv_basename)
csv_size = json_to_mt5_csv(out_file, csv_file, offset_h)
print(f'\nMT5 CSV saved: {csv_file}')
print(f'  Size: {csv_size:.1f} MB')
print(f'\nImport into MetaTrader 5:')
print(f'  1. MT5 -> File -> Import -> Select the CSV file')
print(f'  2. Format: DateTime, Bid, Ask  (single DateTime column, NO offset needed)')
print(f'  3. DateTime format: YYYY.MM.DD HH:MM:SS.FFF')
print(f'  4. Tick data: uncheck "Use first row as header"')
print(f'  5. Set time offset = 0 (already in server time)')
