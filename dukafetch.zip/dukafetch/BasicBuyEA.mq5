input double LotSize = 0.01;
input int CloseSecondsBefore = 20;

datetime lastCandleTime = 0;
int tradeTick = 0;
ulong ticket = 0;

int OnInit() { return INIT_SUCCEEDED; }

void OnDeinit(const int reason) {}

void OnTick()
{
   datetime barTime = iTime(_Symbol, PERIOD_CURRENT, 0);
   if (barTime == 0) return;

   if (lastCandleTime != barTime)
   {
      lastCandleTime = barTime;
      tradeTick = 0;

      CloseAllBuy();
      OpenBuy();
   }

   if (ticket > 0)
   {
      int periodSec = PeriodSeconds(PERIOD_CURRENT);
      datetime closeTime = barTime + periodSec;
      if (TimeCurrent() >= closeTime - CloseSecondsBefore)
      {
         CloseAllBuy();
      }
   }
}

void OpenBuy()
{
   MqlTradeRequest req = {};
   MqlTradeResult res = {};
   req.action = TRADE_ACTION_DEAL;
   req.symbol = _Symbol;
   req.volume = LotSize;
   req.type = ORDER_TYPE_BUY;
   req.price = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   req.deviation = 10;
   req.magic = 123456;
   req.comment = "BasicBuyEA";

   if (OrderSend(req, res) && res.retcode == TRADE_RETCODE_DONE)
      ticket = res.order;
}

void CloseAllBuy()
{
   for (int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong posTicket = PositionGetTicket(i);
      if (!PositionSelectByTicket(posTicket)) continue;
      if (PositionGetString(POSITION_SYMBOL) != _Symbol) continue;
      if (PositionGetInteger(POSITION_TYPE) != POSITION_TYPE_BUY) continue;

      MqlTradeRequest req = {};
      MqlTradeResult res = {};
      req.action = TRADE_ACTION_DEAL;
      req.symbol = _Symbol;
      req.volume = PositionGetDouble(POSITION_VOLUME);
      req.type = ORDER_TYPE_SELL;
      req.price = SymbolInfoDouble(_Symbol, SYMBOL_BID);
      req.deviation = 10;
      req.magic = 123456;
      req.position = posTicket;

      OrderSend(req, res);
   }
   ticket = 0;
}
