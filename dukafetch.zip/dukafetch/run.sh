#!/usr/bin/env bash
cd "$(dirname "$0")"
python3 duka_fetch.py
